import Foundation
import SwiftUI

class FontScheme: NSObject {
    static func kInterRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kInterRegular, size: size)
    }

    static func kInterBlack(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kInterBlack, size: size)
    }

    static func kInterExtraBold(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kInterExtraBold, size: size)
    }

    static func kInterBold(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kInterBold, size: size)
    }

    static func kDomineRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kDomineRegular, size: size)
    }

    static func kDomineBold(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kDomineBold, size: size)
    }

    static func kShrikhandRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kShrikhandRegular, size: size)
    }

    static func kSrirachaRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kSrirachaRegular, size: size)
    }

    static func kSigmarOneRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kSigmarOneRegular, size: size)
    }

    static func kShortStack(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kShortStack, size: size)
    }

    static func kNunitoBold(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kNunitoBold, size: size)
    }

    static func fontFromConstant(fontName: String, size: CGFloat) -> Font {
        var result = Font.system(size: size)

        switch fontName {
        case "kInterRegular":
            result = self.kInterRegular(size: size)
        case "kInterBlack":
            result = self.kInterBlack(size: size)
        case "kInterExtraBold":
            result = self.kInterExtraBold(size: size)
        case "kInterBold":
            result = self.kInterBold(size: size)
        case "kDomineRegular":
            result = self.kDomineRegular(size: size)
        case "kDomineBold":
            result = self.kDomineBold(size: size)
        case "kShrikhandRegular":
            result = self.kShrikhandRegular(size: size)
        case "kSrirachaRegular":
            result = self.kSrirachaRegular(size: size)
        case "kSigmarOneRegular":
            result = self.kSigmarOneRegular(size: size)
        case "kShortStack":
            result = self.kShortStack(size: size)
        case "kNunitoBold":
            result = self.kNunitoBold(size: size)
        default:
            result = self.kInterRegular(size: size)
        }
        return result
    }

    enum FontConstant {
        /**
         * Please Add this fonts Manually
         */
        static let kInterRegular: String = "InterRegular"
        /**
         * Please Add this fonts Manually
         */
        static let kInterBlack: String = "Inter-Black"
        /**
         * Please Add this fonts Manually
         */
        static let kInterExtraBold: String = "Inter-ExtraBold"
        /**
         * Please Add this fonts Manually
         */
        static let kInterBold: String = "Inter-Bold"
        /**
         * Please Add this fonts Manually
         */
        static let kDomineRegular: String = "Domine-Regular"
        /**
         * Please Add this fonts Manually
         */
        static let kDomineBold: String = "Domine-Bold"
        /**
         * Please Add this fonts Manually
         */
        static let kShrikhandRegular: String = "Shrikhand-Regular"
        /**
         * Please Add this fonts Manually
         */
        static let kSrirachaRegular: String = "Sriracha-Regular"
        /**
         * Please Add this fonts Manually
         */
        static let kSigmarOneRegular: String = "SigmarOne-Regular"
        /**
         * Please Add this fonts Manually
         */
        static let kShortStack: String = "ShortStack"
        /**
         * Please Add this fonts Manually
         */
        static let kNunitoBold: String = "Nunito-Bold"
    }
}

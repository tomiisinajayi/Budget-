//
//  AppConstants.swift
//  Budget

import Foundation

struct AppConstants {
    static let serverURL: String = "@{serverURL}"
}

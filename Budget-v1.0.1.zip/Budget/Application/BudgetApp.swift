//
//  BudgetApp.swift
//  Budget

import SwiftUI

@main
struct BudgetApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            WelcomePageView()
        }
    }
}

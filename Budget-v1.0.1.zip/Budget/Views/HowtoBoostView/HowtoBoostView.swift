import SwiftUI

struct HowtoBoostView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            ZStack {
                ScrollView(.vertical, showsIndicators: false) {
                    ZStack(alignment: .topLeading) {
                        Text(StringConstants.kLblSlide)
                            .font(FontScheme.kInterRegular(size: getRelativeHeight(100.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(265.0), height: getRelativeHeight(100.0),
                                   alignment: .topLeading)
                            .padding(.bottom, getRelativeHeight(565.22))
                            .padding(.trailing, getRelativeWidth(115.32))
                        ZStack(alignment: .bottomLeading) {
                            Image("img_screenshot2023")
                                .resizable()
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(756.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .background(RoundedCorners(topLeft: 13.0, topRight: 13.0,
                                                           bottomLeft: 13.0, bottomRight: 13.0))
                            ZStack {}
                                .hideNavigationBar()
                                .frame(width: getRelativeWidth(97.0),
                                       height: getRelativeHeight(40.0), alignment: .bottomLeading)
                                .background(ColorConstants.WhiteA700)
                                .padding(.top, getRelativeHeight(593.0))
                                .padding(.trailing, getRelativeWidth(333.0))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(756.0),
                               alignment: .topLeading)
                        .padding(.bottom, getRelativeHeight(122.0))
                        VStack {
                            Button(action: {}, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLblClose)
                                        .font(FontScheme
                                            .kDomineRegular(size: getRelativeHeight(25.0)))
                                        .fontWeight(.regular)
                                        .padding(.horizontal, getRelativeWidth(30.0))
                                        .padding(.vertical, getRelativeHeight(16.0))
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: getRelativeWidth(264.0),
                                               height: getRelativeHeight(57.0), alignment: .center)
                                        .overlay(RoundedCorners(topLeft: 15.0, topRight: 15.0,
                                                                bottomLeft: 15.0, bottomRight: 15.0)
                                                .stroke(ColorConstants.Black900,
                                                        lineWidth: 2))
                                        .background(RoundedCorners(topLeft: 15.0, topRight: 15.0,
                                                                   bottomLeft: 15.0,
                                                                   bottomRight: 15.0)
                                                .fill(Color.clear.opacity(0.7)))
                                        .padding(.top, getRelativeHeight(21.0))
                                        .padding(.bottom, getRelativeHeight(20.0))
                                        .padding(.leading, getRelativeWidth(88.0))
                                        .padding(.trailing, getRelativeWidth(78.0))
                                }
                            })
                            .frame(width: getRelativeWidth(264.0), height: getRelativeHeight(57.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 15.0, topRight: 15.0, bottomLeft: 15.0,
                                                    bottomRight: 15.0)
                                    .stroke(ColorConstants.Black900,
                                            lineWidth: 2))
                            .background(RoundedCorners(topLeft: 15.0, topRight: 15.0,
                                                       bottomLeft: 15.0, bottomRight: 15.0)
                                    .fill(Color.clear.opacity(0.7)))
                            .padding(.top, getRelativeHeight(21.0))
                            .padding(.bottom, getRelativeHeight(20.0))
                            .padding(.leading, getRelativeWidth(88.0))
                            .padding(.trailing, getRelativeWidth(78.0))
                        }
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(128.0),
                               alignment: .bottomLeading)
                        .background(ColorConstants.DeepPurpleA200)
                        .padding(.top, getRelativeHeight(832.0))
                        Image("img_rectangle19")
                            .resizable()
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(100.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.bottom, getRelativeHeight(860.0))
                        Image("img_rectangle22")
                            .resizable()
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(130.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.bottom, getRelativeHeight(830.0))
                    }
                    .hideNavigationBar()
                    .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height,
                           alignment: .topLeading)
                }
            }
            .hideNavigationBar()
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct HowtoBoostView_Previews: PreviewProvider {
    static var previews: some View {
        HowtoBoostView()
    }
}

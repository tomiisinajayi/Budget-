import SwiftUI

struct IPhonePlusSixView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack(alignment: .leading, spacing: 0) {
                Group {
                    VStack {
                        Text(StringConstants.kLblYourInfo)
                            .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.DeepPurpleA200)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(249.0), height: getRelativeHeight(48.0),
                                   alignment: .topLeading)
                            .padding(.leading, getRelativeWidth(72.0))
                            .padding(.trailing, getRelativeWidth(53.0))
                    }
                    .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(48.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(69.0))
                    .padding(.horizontal, getRelativeWidth(17.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kLblMonthlyIncome)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Purple700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(177.0), height: getRelativeHeight(25.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(15.0))
                    }
                    .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(25.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(49.0))
                    .padding(.horizontal, getRelativeWidth(17.0))
                    VStack {
                        Text(StringConstants.kLbl2340)
                            .font(FontScheme.kInterBlack(size: getRelativeHeight(15.0)))
                            .fontWeight(.black)
                            .padding(.leading, getRelativeWidth(16.0))
                            .padding(.vertical, getRelativeHeight(14.0))
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(360.0), height: getRelativeHeight(44.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                    bottomRight: 8.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 2))
                            .background(ColorConstants.WhiteA700)
                            .padding(.leading, getRelativeWidth(15.0))
                    }
                    .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(44.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(9.0))
                    .padding(.horizontal, getRelativeWidth(17.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kMsgMonthlyNeedsA)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Purple700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(290.0), height: getRelativeHeight(26.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(15.0))
                    }
                    .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(26.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(16.0))
                    .padding(.horizontal, getRelativeWidth(17.0))
                    VStack {
                        VStack {
                            Text(StringConstants.kMsgGroceries120)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(20.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(304.0),
                                       height: getRelativeHeight(89.0), alignment: .topLeading)
                                .padding(.vertical, getRelativeHeight(18.0))
                                .padding(.horizontal, getRelativeWidth(15.0))
                        }
                        .frame(width: getRelativeWidth(360.0), height: getRelativeHeight(127.0),
                               alignment: .center)
                        .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                bottomRight: 8.0)
                                .stroke(ColorConstants.Bluegray100,
                                        lineWidth: 2))
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0)
                                .fill(ColorConstants.WhiteA700))
                        .padding(.leading, getRelativeWidth(15.0))
                    }
                    .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(127.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(8.0))
                    .padding(.horizontal, getRelativeWidth(17.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kMsgMonthlyWantsA)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Purple700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(290.0), height: getRelativeHeight(25.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(15.0))
                    }
                    .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(25.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(14.0))
                    .padding(.horizontal, getRelativeWidth(17.0))
                    VStack {
                        VStack {
                            Text(StringConstants.kMsgPlaystationPlu)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(20.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(309.0),
                                       height: getRelativeHeight(159.0), alignment: .topLeading)
                                .padding(.vertical, getRelativeHeight(9.0))
                                .padding(.horizontal, getRelativeWidth(16.0))
                        }
                        .frame(width: getRelativeWidth(354.0), height: getRelativeHeight(179.0),
                               alignment: .center)
                        .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                bottomRight: 8.0)
                                .stroke(ColorConstants.Bluegray100,
                                        lineWidth: 2))
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0)
                                .fill(ColorConstants.WhiteA700))
                        .padding(.leading, getRelativeWidth(18.0))
                    }
                    .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(179.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(6.0))
                    .padding(.horizontal, getRelativeWidth(17.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kMsgMonthlyWantsA)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Purple700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(290.0), height: getRelativeHeight(25.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(15.0))
                    }
                    .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(25.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(19.0))
                    .padding(.horizontal, getRelativeWidth(17.0))
                }
                Group {
                    VStack {
                        VStack {
                            Text(StringConstants.kMsgGeneralSaving)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(20.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(299.0),
                                       height: getRelativeHeight(124.0), alignment: .topLeading)
                                .padding(.vertical, getRelativeHeight(12.0))
                                .padding(.horizontal, getRelativeWidth(16.0))
                        }
                        .frame(width: getRelativeWidth(360.0), height: getRelativeHeight(150.0),
                               alignment: .center)
                        .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                bottomRight: 8.0)
                                .stroke(ColorConstants.Bluegray100,
                                        lineWidth: 2))
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0)
                                .fill(ColorConstants.WhiteA700))
                        .padding(.leading, getRelativeWidth(15.0))
                    }
                    .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(150.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(7.0))
                    .padding(.horizontal, getRelativeWidth(17.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblBack)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(30.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(15.0))
                                    .padding(.vertical, getRelativeHeight(7.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(100.0),
                                           height: getRelativeHeight(45.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 22.5, topRight: 22.5,
                                                               bottomLeft: 22.5, bottomRight: 22.5)
                                            .fill(ColorConstants.DeepPurpleA200))
                                    .padding(.trailing, getRelativeWidth(10.0))
                            }
                        })
                        .frame(width: getRelativeWidth(100.0), height: getRelativeHeight(45.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 22.5, topRight: 22.5, bottomLeft: 22.5,
                                                   bottomRight: 22.5)
                                .fill(ColorConstants.DeepPurpleA200))
                        .padding(.trailing)
                    }
                    .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(45.0),
                           alignment: .leading)
                    .padding(.vertical, getRelativeHeight(17.0))
                    .padding(.horizontal, getRelativeWidth(17.0))
                }
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct IPhonePlusSixView_Previews: PreviewProvider {
    static var previews: some View {
        IPhonePlusSixView()
    }
}

import SwiftUI

struct MakingsenseView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            ZStack {
                ZStack(alignment: .topLeading) {
                    VStack {
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblClose)
                                    .font(FontScheme.kDomineRegular(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(16.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(264.0),
                                           height: getRelativeHeight(57.0), alignment: .center)
                                    .overlay(RoundedCorners(topLeft: 15.0, topRight: 15.0,
                                                            bottomLeft: 15.0, bottomRight: 15.0)
                                            .stroke(ColorConstants.Black900,
                                                    lineWidth: 2))
                                    .background(RoundedCorners(topLeft: 15.0, topRight: 15.0,
                                                               bottomLeft: 15.0, bottomRight: 15.0)
                                            .fill(Color.clear.opacity(0.7)))
                                    .padding(.vertical, getRelativeHeight(58.0))
                                    .padding(.horizontal, getRelativeWidth(75.0))
                            }
                        })
                        .frame(width: getRelativeWidth(264.0), height: getRelativeHeight(57.0),
                               alignment: .center)
                        .overlay(RoundedCorners(topLeft: 15.0, topRight: 15.0, bottomLeft: 15.0,
                                                bottomRight: 15.0)
                                .stroke(ColorConstants.Black900,
                                        lineWidth: 2))
                        .background(RoundedCorners(topLeft: 15.0, topRight: 15.0, bottomLeft: 15.0,
                                                   bottomRight: 15.0)
                                .fill(Color.clear.opacity(0.7)))
                        .padding(.vertical, getRelativeHeight(58.0))
                        .padding(.horizontal, getRelativeWidth(75.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(128.0),
                           alignment: .bottomLeading)
                    .background(ColorConstants.DeepPurpleA200)
                    .padding(.top, getRelativeHeight(799.0))
                    Image("img_rectangle21")
                        .resizable()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(129.0),
                               alignment: .center)
                        .scaledToFit()
                        .clipped()
                        .padding(.bottom, getRelativeHeight(798.0))
                    Image("img_899541")
                        .resizable()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(751.0),
                               alignment: .center)
                        .scaledToFit()
                        .clipped()
                }
                .hideNavigationBar()
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height,
                       alignment: .topLeading)
                .background(ColorConstants.WhiteA700)
            }
            .hideNavigationBar()
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct MakingsenseView_Previews: PreviewProvider {
    static var previews: some View {
        MakingsenseView()
    }
}

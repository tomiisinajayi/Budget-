import SwiftUI

struct PaymentView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        Group {
                            ZStack(alignment: .leading) {
                                Divider()
                                    .frame(width: UIScreen.main.bounds.width,
                                           height: getRelativeHeight(1.0),
                                           alignment: .bottomLeading)
                                    .background(ColorConstants.Gray70056)
                                    .padding(.top, getRelativeHeight(61.97))
                                Image("img_line4")
                                    .resizable()
                                    .frame(width: getRelativeWidth(76.0),
                                           height: getRelativeWidth(76.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.trailing, getRelativeWidth(354.0))
                            }
                            .hideNavigationBar()
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(76.0), alignment: .leading)
                            Text(StringConstants.kLblPayment)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(229.0),
                                       height: getRelativeHeight(48.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(21.0))
                                .padding(.horizontal, getRelativeWidth(23.0))
                            Text(StringConstants.kLblStudentLoans)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(156.0),
                                       height: getRelativeHeight(25.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(31.0))
                                .padding(.horizontal, getRelativeWidth(23.0))
                            VStack {
                                ZStack {}
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(140.0),
                                           height: getRelativeHeight(27.0), alignment: .leading)
                                    .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                               bottomLeft: 10.0, bottomRight: 10.0)
                                            .fill(ColorConstants.DeepPurpleA200))
                                    .padding(.trailing, getRelativeWidth(110.0))
                            }
                            .frame(width: getRelativeWidth(250.0), height: getRelativeHeight(27.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                       bottomLeft: 10.0, bottomRight: 10.0)
                                    .fill(ColorConstants.Bluegray100))
                            .padding(.horizontal, getRelativeWidth(23.0))
                            Text(StringConstants.kMsg10000Of20)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(288.0),
                                       height: getRelativeHeight(25.0), alignment: .center)
                                .padding(.top, getRelativeHeight(16.0))
                                .padding(.horizontal, getRelativeWidth(23.0))
                            ZStack(alignment: .topLeading) {
                                HStack {
                                    VStack(alignment: .leading, spacing: 0) {
                                        Text(StringConstants.kLblVisaDebit3456)
                                            .font(FontScheme
                                                .kSrirachaRegular(size: getRelativeHeight(23.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(161.0),
                                                   height: getRelativeHeight(23.0),
                                                   alignment: .topLeading)
                                        Text(StringConstants.kLbl04022023)
                                            .font(FontScheme
                                                .kSrirachaRegular(size: getRelativeHeight(15.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(87.0),
                                                   height: getRelativeHeight(15.0),
                                                   alignment: .topLeading)
                                            .padding(.top, getRelativeHeight(9.0))
                                            .padding(.leading, getRelativeWidth(5.0))
                                            .padding(.trailing, getRelativeWidth(10.0))
                                    }
                                    .frame(width: getRelativeWidth(161.0),
                                           height: getRelativeHeight(47.0), alignment: .center)
                                    .padding(.leading, getRelativeWidth(23.0))
                                    Text(StringConstants.kLbl200)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(68.0),
                                               height: getRelativeHeight(20.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(115.0))
                                        .padding(.trailing, getRelativeWidth(9.0))
                                }
                                .frame(width: getRelativeWidth(376.0),
                                       height: getRelativeHeight(82.0), alignment: .bottomLeading)
                                .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                           bottomLeft: 10.0, bottomRight: 10.0)
                                        .fill(ColorConstants.Bluegray100))
                                .padding(.top, getRelativeHeight(24.04))
                                Text(StringConstants.kLblRecentActivity)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(173.0),
                                           height: getRelativeHeight(25.0), alignment: .topLeading)
                                    .padding(.bottom, getRelativeHeight(81.0))
                                    .padding(.trailing, getRelativeWidth(191.0))
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(376.0), height: getRelativeHeight(106.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(38.0))
                            .padding(.horizontal, getRelativeWidth(23.0))
                            HStack {
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(StringConstants.kLblVisaDebit3456)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(23.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(161.0),
                                               height: getRelativeHeight(23.0),
                                               alignment: .topLeading)
                                    Text(StringConstants.kLbl03192023)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(15.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(84.0),
                                               height: getRelativeHeight(15.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(9.0))
                                        .padding(.leading, getRelativeWidth(5.0))
                                        .padding(.trailing, getRelativeWidth(10.0))
                                }
                                .frame(width: getRelativeWidth(161.0),
                                       height: getRelativeHeight(47.0), alignment: .center)
                                .padding(.top, getRelativeHeight(16.0))
                                .padding(.bottom, getRelativeHeight(17.0))
                                .padding(.leading, getRelativeWidth(23.0))
                                Spacer()
                                Text(StringConstants.kLbl200)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(68.0),
                                           height: getRelativeHeight(20.0), alignment: .topLeading)
                                    .padding(.vertical, getRelativeHeight(33.0))
                                    .padding(.trailing, getRelativeWidth(10.0))
                            }
                            .frame(width: getRelativeWidth(376.0), height: getRelativeHeight(82.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                       bottomLeft: 10.0, bottomRight: 10.0)
                                    .fill(ColorConstants.Bluegray100))
                            .padding(.top, getRelativeHeight(30.0))
                            .padding(.horizontal, getRelativeWidth(23.0))
                            ZStack(alignment: .center) {
                                VStack {
                                    ZStack {}
                                        .hideNavigationBar()
                                        .frame(width: getRelativeWidth(100.0),
                                               height: getRelativeHeight(27.0), alignment: .leading)
                                        .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                                   bottomLeft: 10.0,
                                                                   bottomRight: 10.0)
                                                .fill(ColorConstants.DeepPurpleA200))
                                        .padding(.trailing, getRelativeWidth(150.0))
                                }
                                .frame(width: getRelativeWidth(250.0),
                                       height: getRelativeHeight(27.0), alignment: .bottomLeading)
                                .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                           bottomLeft: 10.0, bottomRight: 10.0)
                                        .fill(ColorConstants.Bluegray100))
                                .padding(.top, getRelativeHeight(24.57))
                                Text(StringConstants.kMsgCreditCardDeb)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(184.0),
                                           height: getRelativeHeight(25.0), alignment: .center)
                                    .padding(.bottom, getRelativeHeight(26.0))
                                    .padding(.leading, getRelativeWidth(35.1))
                                    .padding(.trailing, getRelativeWidth(30.9))
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(250.0), height: getRelativeHeight(51.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(41.0))
                            .padding(.horizontal, getRelativeWidth(23.0))
                        }
                        Group {
                            Text(StringConstants.kMsg150Of625Pa)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(209.0),
                                       height: getRelativeHeight(25.0), alignment: .center)
                                .padding(.top, getRelativeHeight(13.0))
                                .padding(.horizontal, getRelativeWidth(23.0))
                            ZStack(alignment: .topLeading) {
                                HStack {
                                    VStack {
                                        Text(StringConstants.kLblVisaDebit3456)
                                            .font(FontScheme
                                                .kSrirachaRegular(size: getRelativeHeight(23.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(161.0),
                                                   height: getRelativeHeight(23.0),
                                                   alignment: .topLeading)
                                        Text(StringConstants.kLbl04022023)
                                            .font(FontScheme
                                                .kSrirachaRegular(size: getRelativeHeight(15.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(85.0),
                                                   height: getRelativeHeight(15.0),
                                                   alignment: .topLeading)
                                            .padding(.top, getRelativeHeight(8.0))
                                            .padding(.leading, getRelativeWidth(6.0))
                                            .padding(.trailing, getRelativeWidth(10.0))
                                    }
                                    .frame(width: getRelativeWidth(161.0),
                                           height: getRelativeHeight(46.0), alignment: .bottom)
                                    .padding(.leading, getRelativeWidth(27.0))
                                    Text(StringConstants.kLbl50)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(56.0),
                                               height: getRelativeHeight(20.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(125.0))
                                        .padding(.trailing, getRelativeWidth(15.0))
                                }
                                .frame(width: getRelativeWidth(384.0),
                                       height: getRelativeHeight(81.0), alignment: .bottomLeading)
                                .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                           bottomLeft: 10.0, bottomRight: 10.0)
                                        .fill(ColorConstants.Bluegray100))
                                .padding(.top, getRelativeHeight(22.04))
                                Text(StringConstants.kLblRecentActivity)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(173.0),
                                           height: getRelativeHeight(25.0), alignment: .topLeading)
                                    .padding(.bottom, getRelativeHeight(78.0))
                                    .padding(.trailing, getRelativeWidth(199.0))
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(384.0), height: getRelativeHeight(103.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(28.0))
                            .padding(.horizontal, getRelativeWidth(23.0))
                            HStack {
                                VStack {
                                    Text(StringConstants.kLblVisaDebit3456)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(23.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(161.0),
                                               height: getRelativeHeight(23.0),
                                               alignment: .topLeading)
                                    Text(StringConstants.kLbl03192023)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(15.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(82.0),
                                               height: getRelativeHeight(15.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(8.0))
                                        .padding(.horizontal, getRelativeWidth(14.0))
                                }
                                .frame(width: getRelativeWidth(161.0),
                                       height: getRelativeHeight(46.0), alignment: .center)
                                .padding(.top, getRelativeHeight(13.0))
                                .padding(.bottom, getRelativeHeight(14.0))
                                .padding(.leading, getRelativeWidth(26.0))
                                Spacer()
                                Text(StringConstants.kLbl50)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(56.0),
                                           height: getRelativeHeight(20.0), alignment: .topLeading)
                                    .padding(.vertical, getRelativeHeight(34.0))
                                    .padding(.trailing, getRelativeWidth(15.0))
                            }
                            .frame(width: getRelativeWidth(384.0), height: getRelativeHeight(75.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                       bottomLeft: 10.0, bottomRight: 10.0)
                                    .fill(ColorConstants.Bluegray100))
                            .padding(.top, getRelativeHeight(21.0))
                            .padding(.horizontal, getRelativeWidth(23.0))
                        }
                    }
                    .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                }
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.vertical, getRelativeHeight(17.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct PaymentView_Previews: PreviewProvider {
    static var previews: some View {
        PaymentView()
    }
}

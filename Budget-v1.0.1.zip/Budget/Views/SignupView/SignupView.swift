import SwiftUI

struct SignupView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        Image("img_image1")
                            .resizable()
                            .frame(width: getRelativeWidth(245.0), height: getRelativeHeight(248.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.horizontal, getRelativeWidth(34.0))
                        Text(StringConstants.kLblFirstName)
                            .font(FontScheme.kInterBlack(size: getRelativeHeight(16.842106)))
                            .fontWeight(.black)
                            .padding(.leading, getRelativeWidth(22.0))
                            .padding(.vertical, getRelativeHeight(30.0))
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(338.0), height: getRelativeHeight(80.0),
                                   alignment: .topLeading)
                            .background(ColorConstants.Bluegray100)
                            .padding(.top, getRelativeHeight(34.0))
                        Text(StringConstants.kLblLastName)
                            .font(FontScheme.kInterBlack(size: getRelativeHeight(16.842106)))
                            .fontWeight(.black)
                            .padding(.leading, getRelativeWidth(25.0))
                            .padding(.vertical, getRelativeHeight(30.0))
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(338.0), height: getRelativeHeight(80.0),
                                   alignment: .topLeading)
                            .background(ColorConstants.Bluegray100)
                            .padding(.top, getRelativeHeight(30.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblSignUp)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(15.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(150.0),
                                           height: getRelativeHeight(50.0), alignment: .topLeading)
                                    .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                               bottomLeft: 10.0, bottomRight: 10.0)
                                            .fill(ColorConstants.DeepPurpleA200))
                                    .padding(.top, getRelativeHeight(185.0))
                                    .padding(.horizontal, getRelativeWidth(34.0))
                            }
                        })
                        .frame(width: getRelativeWidth(150.0), height: getRelativeHeight(50.0),
                               alignment: .topLeading)
                        .background(RoundedCorners(topLeft: 10.0, topRight: 10.0, bottomLeft: 10.0,
                                                   bottomRight: 10.0)
                                .fill(ColorConstants.DeepPurpleA200))
                        .padding(.top, getRelativeHeight(185.0))
                        .padding(.horizontal, getRelativeWidth(34.0))
                    }
                    .frame(width: getRelativeWidth(338.0), alignment: .topLeading)
                }
            }
            .frame(width: getRelativeWidth(338.0), alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.vertical, getRelativeHeight(115.0))
            .padding(.horizontal, getRelativeWidth(46.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct SignupView_Previews: PreviewProvider {
    static var previews: some View {
        SignupView()
    }
}

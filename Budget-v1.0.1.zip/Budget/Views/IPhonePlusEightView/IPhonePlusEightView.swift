import SwiftUI

struct IPhonePlusEightView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        Image("img_line4")
                            .resizable()
                            .frame(width: getRelativeWidth(76.0), height: getRelativeWidth(76.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.trailing, getRelativeWidth(10.0))
                        VStack {
                            Text(StringConstants.kMsgSavingsChallen2)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(250.0),
                                       height: getRelativeHeight(115.0), alignment: .center)
                                .padding(.horizontal, getRelativeWidth(66.0))
                            Text(StringConstants.kMsgYouHave90Day)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(385.0),
                                       height: getRelativeHeight(84.0), alignment: .center)
                                .padding(.top, getRelativeHeight(85.0))
                            Text(StringConstants.kMsgTodayYouShoul)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(242.0),
                                       height: getRelativeHeight(26.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(46.0))
                                .padding(.horizontal, getRelativeWidth(66.0))
                            VStack {
                                Button(action: {}, label: {
                                    HStack(spacing: 0) {
                                        Text(StringConstants.kLblApril162023)
                                            .font(FontScheme
                                                .kInterBold(size: getRelativeHeight(16.0)))
                                            .fontWeight(.bold)
                                            .padding(.horizontal, getRelativeWidth(16.0))
                                            .padding(.vertical, getRelativeHeight(6.0))
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.center)
                                            .frame(width: getRelativeWidth(138.0),
                                                   height: getRelativeHeight(31.0),
                                                   alignment: .center)
                                            .background(RoundedCorners(topLeft: 15.5,
                                                                       topRight: 15.5,
                                                                       bottomLeft: 15.5,
                                                                       bottomRight: 15.5)
                                                    .fill(ColorConstants.Bluegray50))
                                            .padding(.top, getRelativeHeight(31.0))
                                            .padding(.horizontal, getRelativeWidth(36.0))
                                    }
                                })
                                .frame(width: getRelativeWidth(138.0),
                                       height: getRelativeHeight(31.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 15.5, topRight: 15.5,
                                                           bottomLeft: 15.5, bottomRight: 15.5)
                                        .fill(ColorConstants.Bluegray50))
                                .padding(.top, getRelativeHeight(31.0))
                                .padding(.horizontal, getRelativeWidth(36.0))
                                Text(StringConstants.kLbl11)
                                    .font(FontScheme.kInterExtraBold(size: getRelativeHeight(64.0)))
                                    .fontWeight(.heavy)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(97.0),
                                           height: getRelativeHeight(64.0), alignment: .topLeading)
                                    .padding(.vertical, getRelativeHeight(42.0))
                                    .padding(.horizontal, getRelativeWidth(43.0))
                            }
                            .frame(width: getRelativeWidth(210.0), height: getRelativeHeight(220.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                    bottomRight: 8.0)
                                    .stroke(ColorConstants.IndigoA200,
                                            lineWidth: 2))
                            .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                       bottomRight: 8.0)
                                    .fill(ColorConstants.WhiteA700))
                            .padding(.top, getRelativeHeight(53.0))
                            .padding(.horizontal, getRelativeWidth(66.0))
                            HStack {
                                Button(action: {}, label: {
                                    HStack(spacing: 0) {
                                        Text(StringConstants.kLblReRoll)
                                            .font(FontScheme
                                                .kSrirachaRegular(size: getRelativeHeight(20.0)))
                                            .fontWeight(.regular)
                                            .padding(.horizontal, getRelativeWidth(30.0))
                                            .padding(.vertical, getRelativeHeight(10.0))
                                            .foregroundColor(ColorConstants.WhiteA700)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.center)
                                            .frame(width: getRelativeWidth(161.0),
                                                   height: getRelativeHeight(40.0),
                                                   alignment: .center)
                                            .background(RoundedCorners(topLeft: 5.0, topRight: 5.0,
                                                                       bottomLeft: 5.0,
                                                                       bottomRight: 5.0)
                                                    .fill(ColorConstants.DeepPurpleA200))
                                            .padding(.top, getRelativeHeight(5.0))
                                            .padding(.bottom, getRelativeHeight(4.0))
                                    }
                                })
                                .frame(width: getRelativeWidth(161.0),
                                       height: getRelativeHeight(40.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 5.0, topRight: 5.0,
                                                           bottomLeft: 5.0, bottomRight: 5.0)
                                        .fill(ColorConstants.DeepPurpleA200))
                                .padding(.top, getRelativeHeight(5.0))
                                .padding(.bottom, getRelativeHeight(4.0))
                                Image("img_image3")
                                    .resizable()
                                    .frame(width: getRelativeWidth(49.0),
                                           height: getRelativeWidth(49.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.leading, getRelativeWidth(17.0))
                            }
                            .frame(width: getRelativeWidth(227.0), height: getRelativeHeight(49.0),
                                   alignment: .trailing)
                            .padding(.top, getRelativeHeight(26.0))
                            .padding(.horizontal, getRelativeWidth(49.0))
                            Button(action: {}, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLblPay11)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .padding(.horizontal, getRelativeWidth(30.0))
                                        .padding(.vertical, getRelativeHeight(9.0))
                                        .foregroundColor(ColorConstants.WhiteA700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: getRelativeWidth(161.0),
                                               height: getRelativeHeight(40.0), alignment: .center)
                                        .background(RoundedCorners(topLeft: 5.0, topRight: 5.0,
                                                                   bottomLeft: 5.0,
                                                                   bottomRight: 5.0)
                                                .fill(ColorConstants.DeepPurpleA200))
                                        .padding(.top, getRelativeHeight(18.0))
                                        .padding(.horizontal, getRelativeWidth(49.0))
                                }
                            })
                            .frame(width: getRelativeWidth(161.0), height: getRelativeHeight(40.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 5.0, topRight: 5.0, bottomLeft: 5.0,
                                                       bottomRight: 5.0)
                                    .fill(ColorConstants.DeepPurpleA200))
                            .padding(.top, getRelativeHeight(18.0))
                            .padding(.horizontal, getRelativeWidth(49.0))
                        }
                        .frame(width: getRelativeWidth(385.0), height: getRelativeHeight(765.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(4.0))
                        .padding(.leading, getRelativeWidth(14.0))
                    }
                    .frame(width: getRelativeWidth(399.0), alignment: .topLeading)
                }
            }
            .frame(width: getRelativeWidth(399.0), alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.bottom, getRelativeHeight(87.0))
            .padding(.leading, getRelativeWidth(10.0))
            .padding(.trailing, getRelativeWidth(20.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct IPhonePlusEightView_Previews: PreviewProvider {
    static var previews: some View {
        IPhonePlusEightView()
    }
}

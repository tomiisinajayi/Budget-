import SwiftUI

struct BudgetMasterView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        ZStack(alignment: .leading) {
                            Divider()
                                .frame(width: getRelativeWidth(427.0),
                                       height: getRelativeHeight(1.0), alignment: .topLeading)
                                .background(ColorConstants.Gray70056)
                                .padding(.bottom, getRelativeHeight(66.0))
                            Image("img_icons8openmen_76x74")
                                .resizable()
                                .frame(width: getRelativeWidth(74.0),
                                       height: getRelativeHeight(76.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.trailing, getRelativeWidth(353.0))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(427.0), height: getRelativeHeight(76.0),
                               alignment: .leading)
                        Text(StringConstants.kLblBudgetMaster2)
                            .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.DeepPurpleA200)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(381.0), height: getRelativeHeight(48.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(24.0))
                        Text(StringConstants.kMsgItIsPivotalT)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(20.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(361.0), height: getRelativeHeight(86.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(90.0))
                            .padding(.horizontal, getRelativeWidth(24.0))
                        ZStack(alignment: .center) {
                            ZStack {}
                                .hideNavigationBar()
                                .frame(width: getRelativeWidth(338.0),
                                       height: getRelativeHeight(317.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 169.0, topRight: 169.0,
                                                           bottomLeft: 169.0, bottomRight: 169.0)
                                        .fill(ColorConstants.DeepPurpleA201))
                                .shadow(color: ColorConstants.Black9003f, radius: 4, x: 0, y: 4)
                                .padding(.trailing, getRelativeWidth(7.0))
                            ZStack {}
                                .hideNavigationBar()
                                .frame(width: getRelativeWidth(338.0),
                                       height: getRelativeHeight(317.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 169.0, topRight: 169.0,
                                                           bottomLeft: 169.0, bottomRight: 169.0)
                                        .fill(ColorConstants.Bluegray100))
                                .shadow(color: ColorConstants.Black9003f, radius: 4, x: 0, y: 4)
                                .padding(.horizontal, getRelativeWidth(3.0))
                            ZStack {}
                                .hideNavigationBar()
                                .frame(width: getRelativeWidth(338.0),
                                       height: getRelativeHeight(317.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 169.0, topRight: 169.0,
                                                           bottomLeft: 169.0, bottomRight: 169.0)
                                        .fill(ColorConstants.LightGreenA701))
                                .shadow(color: ColorConstants.Black9003f, radius: 4, x: 0, y: 4)
                                .padding(.horizontal, getRelativeWidth(3.0))
                            VStack {
                                Text(StringConstants.kLbl20Savings)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(67.0),
                                           height: getRelativeHeight(53.0), alignment: .center)
                                    .padding(.horizontal, getRelativeWidth(41.0))
                                HStack {
                                    Text(StringConstants.kLbl50Essentials)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.WhiteA700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: getRelativeWidth(87.0),
                                               height: getRelativeHeight(49.0), alignment: .center)
                                        .padding(.bottom, getRelativeHeight(30.0))
                                    Spacer()
                                    Text(StringConstants.kLbl30Wants)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: getRelativeWidth(52.0),
                                               height: getRelativeHeight(49.0), alignment: .center)
                                        .padding(.top, getRelativeHeight(30.0))
                                }
                                .frame(width: getRelativeWidth(245.0),
                                       height: getRelativeHeight(79.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(47.0))
                            }
                            .frame(width: getRelativeWidth(245.0), height: getRelativeHeight(180.0),
                                   alignment: .topLeading)
                            .padding(.bottom, getRelativeHeight(100.88))
                            .padding(.trailing, getRelativeWidth(61.55))
                            Image("img_ellipse5")
                                .resizable()
                                .frame(width: getRelativeWidth(345.0),
                                       height: getRelativeHeight(319.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(345.0), height: getRelativeHeight(319.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(58.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                    }
                    .frame(width: getRelativeWidth(427.0), alignment: .topLeading)
                }
            }
            .frame(width: getRelativeWidth(427.0), alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.vertical, getRelativeHeight(57.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct BudgetMasterView_Previews: PreviewProvider {
    static var previews: some View {
        BudgetMasterView()
    }
}

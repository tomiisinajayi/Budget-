import SwiftUI

struct MenuHomeView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack(alignment: .trailing, spacing: 0) {
                VStack {
                    HStack {
                        HStack {
                            HStack {
                                ZStack {
                                    Image("img_scott1")
                                        .resizable()
                                        .frame(width: getRelativeWidth(35.0),
                                               height: getRelativeHeight(40.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.leading, getRelativeWidth(6.6))
                                }
                                .hideNavigationBar()
                                .frame(width: getRelativeWidth(44.0),
                                       height: getRelativeHeight(43.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 21.5, topRight: 21.5,
                                                           bottomLeft: 21.5, bottomRight: 21.5)
                                        .fill(ColorConstants.Bluegray100))
                                Text(StringConstants.kLblProfile)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(14.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(10.0))
                                    .padding(.top, getRelativeHeight(4.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(62.0),
                                           height: getRelativeHeight(20.0), alignment: .center)
                                    .background(ColorConstants.Bluegray100)
                                    .padding(.leading, getRelativeWidth(12.0))
                            }
                            .frame(width: getRelativeWidth(118.0), height: getRelativeHeight(43.0),
                                   alignment: .top)
                            .padding(.vertical, getRelativeHeight(7.0))
                            Spacer()
                            ZStack(alignment: .topTrailing) {
                                Image("img_score2")
                                    .resizable()
                                    .frame(width: getRelativeWidth(91.0),
                                           height: getRelativeHeight(45.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.top, getRelativeHeight(17.63))
                                Text(StringConstants.kLbl10)
                                    .font(FontScheme.kInterExtraBold(size: getRelativeHeight(24.0)))
                                    .fontWeight(.heavy)
                                    .foregroundColor(ColorConstants.Purple700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(29.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.bottom, getRelativeHeight(38.0))
                                    .padding(.leading, getRelativeWidth(39.0))
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(91.0), height: getRelativeHeight(62.0),
                                   alignment: .center)
                        }
                        .frame(width: getRelativeWidth(420.0), height: getRelativeHeight(62.0),
                               alignment: .leading)
                    }
                    .frame(width: getRelativeWidth(420.0), height: getRelativeHeight(62.0),
                           alignment: .leading)
                    .padding(.leading, getRelativeWidth(10.0))
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(62.0),
                       alignment: .leading)
                VStack(alignment: .leading, spacing: 0) {
                    VStack {
                        Divider()
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(1.0), alignment: .leading)
                            .background(ColorConstants.Gray70056)
                        VStack {
                            ZStack(alignment: .trailing) {
                                Text(StringConstants.kLbl17)
                                    .font(FontScheme
                                        .kShrikhandRegular(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(32.0),
                                           height: getRelativeHeight(25.0), alignment: .topLeading)
                                    .padding(.trailing, getRelativeWidth(28.0))
                                Image("img_image9")
                                    .resizable()
                                    .frame(width: getRelativeWidth(31.0),
                                           height: getRelativeHeight(27.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.leading, getRelativeWidth(29.93))
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(60.0), height: getRelativeHeight(27.0),
                                   alignment: .trailing)
                            .padding(.leading, getRelativeWidth(10.0))
                            HStack {
                                Text(StringConstants.kLblMenu)
                                    .font(FontScheme
                                        .kShrikhandRegular(size: getRelativeHeight(48.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(143.0),
                                           height: getRelativeHeight(48.0), alignment: .center)
                                Spacer()
                                Text(StringConstants.kLblStreak)
                                    .font(FontScheme
                                        .kShrikhandRegular(size: getRelativeHeight(15.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(53.0),
                                           height: getRelativeHeight(15.0), alignment: .topLeading)
                                    .padding(.bottom, getRelativeHeight(36.0))
                                    .padding(.leading, getRelativeWidth(64.0))
                            }
                            .frame(width: getRelativeWidth(261.0), height: getRelativeHeight(51.0),
                                   alignment: .trailing)
                            .padding(.top, getRelativeHeight(5.0))
                            .padding(.leading, getRelativeWidth(138.0))
                            .padding(.trailing, getRelativeWidth(7.0))
                            ZStack(alignment: .leading) {
                                Group {
                                    ZStack {
                                        Image("img_rectangle9")
                                            .resizable()
                                            .frame(width: getRelativeWidth(76.0),
                                                   height: getRelativeHeight(65.0),
                                                   alignment: .center)
                                            .scaledToFit()
                                            .clipped()
                                            .padding(.vertical, getRelativeHeight(8.0))
                                            .padding(.horizontal, getRelativeWidth(6.0))
                                    }
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(87.0),
                                           height: getRelativeHeight(81.0), alignment: .topTrailing)
                                    .background(ColorConstants.Bluegray100)
                                    .padding(.bottom, getRelativeHeight(322.0))
                                    .padding(.leading, getRelativeWidth(286.0))
                                    ZStack {}
                                        .hideNavigationBar()
                                        .frame(width: getRelativeWidth(87.0),
                                               height: getRelativeHeight(81.0), alignment: .leading)
                                        .background(ColorConstants.Bluegray100)
                                        .padding(.trailing, getRelativeWidth(287.0))
                                    ZStack {}
                                        .hideNavigationBar()
                                        .frame(width: getRelativeWidth(87.0),
                                               height: getRelativeHeight(81.0),
                                               alignment: .topLeading)
                                        .background(ColorConstants.Bluegray100)
                                        .padding(.bottom, getRelativeHeight(322.0))
                                        .padding(.trailing, getRelativeWidth(288.0))
                                    ZStack(alignment: .topLeading) {
                                        ZStack {}
                                            .hideNavigationBar()
                                            .frame(width: getRelativeWidth(164.0),
                                                   height: getRelativeHeight(149.0),
                                                   alignment: .center)
                                            .shadow(color: ColorConstants.Black9003f, radius: 4,
                                                    x: 0, y: 4)
                                            .padding(.bottom, getRelativeHeight(132.71))
                                            .padding(.horizontal, getRelativeWidth(99.45))
                                        ZStack(alignment: .topLeading) {
                                            Image("img_budget32")
                                                .resizable()
                                                .frame(width: getRelativeWidth(362.0),
                                                       height: getRelativeHeight(329.0),
                                                       alignment: .center)
                                                .scaledToFit()
                                                .clipped()
                                            VStack(alignment: .leading, spacing: 0) {
                                                HStack {
                                                    Text(StringConstants.kLblCreditScore)
                                                        .font(FontScheme
                                                            .kShrikhandRegular(size: getRelativeHeight(20.0)))
                                                        .fontWeight(.regular)
                                                        .foregroundColor(ColorConstants
                                                            .DeepPurpleA200)
                                                        .minimumScaleFactor(0.5)
                                                        .multilineTextAlignment(.center)
                                                        .frame(width: getRelativeWidth(75.0),
                                                               height: getRelativeHeight(51.0),
                                                               alignment: .center)
                                                    Spacer()
                                                    Text(StringConstants.kLblSavings)
                                                        .font(FontScheme
                                                            .kShrikhandRegular(size: getRelativeHeight(23.0)))
                                                        .fontWeight(.regular)
                                                        .foregroundColor(ColorConstants
                                                            .DeepPurpleA200)
                                                        .minimumScaleFactor(0.5)
                                                        .multilineTextAlignment(.center)
                                                        .frame(width: getRelativeWidth(97.0),
                                                               height: getRelativeHeight(23.0),
                                                               alignment: .center)
                                                        .padding(.bottom, getRelativeHeight(31.0))
                                                }
                                                .frame(width: getRelativeWidth(229.0),
                                                       height: getRelativeHeight(54.0),
                                                       alignment: .center)
                                                .padding(.leading, getRelativeWidth(6.0))
                                                Image("img_rectangle10")
                                                    .resizable()
                                                    .frame(width: getRelativeWidth(76.0),
                                                           height: getRelativeHeight(65.0),
                                                           alignment: .center)
                                                    .scaledToFit()
                                                    .clipped()
                                                    .padding(.top, getRelativeHeight(30.0))
                                                    .padding(.leading, getRelativeWidth(7.0))
                                                    .padding(.trailing, getRelativeWidth(10.0))
                                                Text(StringConstants.kLblInvestSmart)
                                                    .font(FontScheme
                                                        .kShrikhandRegular(size: getRelativeHeight(23.0)))
                                                    .fontWeight(.regular)
                                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                                    .minimumScaleFactor(0.5)
                                                    .multilineTextAlignment(.center)
                                                    .frame(width: getRelativeWidth(81.0),
                                                           height: getRelativeHeight(49.0),
                                                           alignment: .center)
                                                    .padding(.top, getRelativeHeight(12.0))
                                                    .padding(.trailing, getRelativeWidth(10.0))
                                            }
                                            .frame(width: getRelativeWidth(235.0),
                                                   height: getRelativeHeight(212.0),
                                                   alignment: .topLeading)
                                            .padding(.bottom, getRelativeHeight(66.53))
                                            .padding(.trailing, getRelativeWidth(126.41))
                                        }
                                        .hideNavigationBar()
                                        .frame(width: getRelativeWidth(362.0),
                                               height: getRelativeHeight(329.0),
                                               alignment: .topLeading)
                                        .padding(.bottom, getRelativeHeight(32.0))
                                        ZStack {
                                            Image("img_rectangle17")
                                                .resizable()
                                                .frame(width: getRelativeWidth(76.0),
                                                       height: getRelativeHeight(65.0),
                                                       alignment: .center)
                                                .scaledToFit()
                                                .clipped()
                                                .padding(.top, getRelativeHeight(10.0))
                                                .padding(.horizontal, getRelativeWidth(6.0))
                                        }
                                        .hideNavigationBar()
                                        .frame(width: getRelativeWidth(87.0),
                                               height: getRelativeHeight(81.0),
                                               alignment: .bottomTrailing)
                                        .background(ColorConstants.Bluegray100)
                                        .padding(.top, getRelativeHeight(280.29))
                                        .padding(.leading, getRelativeWidth(146.45))
                                    }
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(362.0),
                                           height: getRelativeHeight(361.0), alignment: .center)
                                    .shadow(color: ColorConstants.Black9003f, radius: 4, x: 0, y: 4)
                                    .padding(.top, getRelativeHeight(39.71))
                                    .padding(.trailing, getRelativeWidth(14.45))
                                    ZStack {
                                        Image("img_budget141")
                                            .resizable()
                                            .frame(width: getRelativeWidth(71.0),
                                                   height: getRelativeHeight(65.0),
                                                   alignment: .center)
                                            .scaledToFit()
                                            .clipped()
                                            .padding(.vertical, getRelativeHeight(8.0))
                                            .padding(.horizontal, getRelativeWidth(7.0))
                                    }
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(87.0),
                                           height: getRelativeHeight(81.0),
                                           alignment: .bottomLeading)
                                    .background(ColorConstants.Bluegray100)
                                    .padding(.top, getRelativeHeight(322.0))
                                    .padding(.trailing, getRelativeWidth(290.0))
                                    ZStack {
                                        Image("img_budget81")
                                            .resizable()
                                            .frame(width: getRelativeWidth(76.0),
                                                   height: getRelativeHeight(65.0),
                                                   alignment: .center)
                                            .scaledToFit()
                                            .clipped()
                                            .padding(.vertical, getRelativeHeight(8.0))
                                            .padding(.horizontal, getRelativeWidth(6.0))
                                    }
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(87.0),
                                           height: getRelativeHeight(81.0),
                                           alignment: .bottomTrailing)
                                    .background(ColorConstants.Bluegray100)
                                    .padding(.top, getRelativeHeight(318.0))
                                    .padding(.leading, getRelativeWidth(286.0))
                                    ZStack {
                                        Image("img_budget121")
                                            .resizable()
                                            .frame(width: getRelativeWidth(76.0),
                                                   height: getRelativeHeight(65.0),
                                                   alignment: .center)
                                            .scaledToFit()
                                            .clipped()
                                            .padding(.vertical, getRelativeHeight(8.0))
                                            .padding(.horizontal, getRelativeWidth(6.0))
                                    }
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(87.0),
                                           height: getRelativeHeight(81.0), alignment: .trailing)
                                    .background(ColorConstants.Bluegray100)
                                    .padding(.leading, getRelativeWidth(286.0))
                                    .padding(.trailing, getRelativeWidth(4.0))
                                    ZStack {
                                        Image("img_budget51")
                                            .resizable()
                                            .frame(width: getRelativeWidth(68.0),
                                                   height: getRelativeHeight(65.0),
                                                   alignment: .center)
                                            .scaledToFit()
                                            .clipped()
                                            .padding(.vertical, getRelativeHeight(8.0))
                                            .padding(.horizontal, getRelativeWidth(9.0))
                                    }
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(87.0),
                                           height: getRelativeHeight(81.0), alignment: .center)
                                    .background(ColorConstants.Bluegray100)
                                    .padding(.bottom, getRelativeHeight(322.0))
                                    .padding(.horizontal, getRelativeWidth(144.0))
                                }
                                Group {
                                    Image("img_rectangle16")
                                        .resizable()
                                        .frame(width: getRelativeWidth(76.0),
                                               height: getRelativeHeight(65.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.bottom, getRelativeHeight(330.0))
                                        .padding(.trailing, getRelativeWidth(293.0))
                                    Text(StringConstants.kLblCrashCourse)
                                        .font(FontScheme
                                            .kShrikhandRegular(size: getRelativeHeight(23.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.DeepPurpleA200)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: getRelativeWidth(85.0),
                                               height: getRelativeHeight(51.0), alignment: .center)
                                        .padding(.bottom, getRelativeHeight(265.0))
                                        .padding(.leading, getRelativeWidth(291.87))
                                    Text(StringConstants.kLblBudgetMaster)
                                        .font(FontScheme
                                            .kShrikhandRegular(size: getRelativeHeight(23.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.DeepPurpleA200)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: getRelativeWidth(89.0),
                                               height: getRelativeHeight(51.0), alignment: .center)
                                        .padding(.top, getRelativeHeight(246.0))
                                        .padding(.leading, getRelativeWidth(285.63))
                                }
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(377.0), height: getRelativeHeight(403.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(69.0))
                            .padding(.horizontal, getRelativeWidth(10.0))
                            HStack {
                                Text(StringConstants.kMsgBraggingRight)
                                    .font(FontScheme
                                        .kShrikhandRegular(size: getRelativeHeight(23.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(118.0),
                                           height: getRelativeHeight(55.0), alignment: .center)
                                Spacer()
                                Text(StringConstants.kLblPayments)
                                    .font(FontScheme
                                        .kShrikhandRegular(size: getRelativeHeight(23.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(122.0),
                                           height: getRelativeHeight(23.0), alignment: .center)
                                    .padding(.vertical, getRelativeHeight(1.0))
                                Spacer()
                                Text(StringConstants.kLblSettings)
                                    .font(FontScheme
                                        .kShrikhandRegular(size: getRelativeHeight(48.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(100.0),
                                           height: getRelativeHeight(21.0), alignment: .center)
                                    .padding(.bottom, getRelativeHeight(35.0))
                            }
                            .frame(width: getRelativeWidth(403.0), height: getRelativeHeight(56.0),
                                   alignment: .center)
                            .padding(.trailing, getRelativeWidth(4.0))
                            Image("img_budget61")
                                .resizable()
                                .frame(width: getRelativeWidth(239.0),
                                       height: getRelativeHeight(193.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(28.0))
                                .padding(.leading, getRelativeWidth(161.0))
                                .padding(.trailing, getRelativeWidth(7.0))
                        }
                        .frame(width: getRelativeWidth(407.0), height: getRelativeHeight(839.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(17.0))
                        .padding(.leading, getRelativeWidth(14.0))
                        .padding(.trailing, getRelativeWidth(8.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(857.0),
                           alignment: .leading)
                    .background(ColorConstants.WhiteA700)
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(857.0),
                       alignment: .leading)
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.top, getRelativeHeight(17.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct MenuHomeView_Previews: PreviewProvider {
    static var previews: some View {
        MenuHomeView()
    }
}

import SwiftUI

struct EmergencyFundView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        ZStack(alignment: .leading) {
                            Divider()
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(1.0), alignment: .bottomLeading)
                                .background(ColorConstants.Gray70056)
                                .padding(.top, getRelativeHeight(66.97))
                            Image("img_icons8openmen_76x69")
                                .resizable()
                                .frame(width: getRelativeWidth(69.0),
                                       height: getRelativeHeight(76.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.trailing, getRelativeWidth(361.0))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(76.0),
                               alignment: .leading)
                        Text(StringConstants.kLblEmergencyFund2)
                            .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.DeepPurpleA200)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(287.0), height: getRelativeHeight(106.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(16.0))
                            .padding(.horizontal, getRelativeWidth(44.0))
                        Text(StringConstants.kMsgAddPerPayP)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(230.0), height: getRelativeHeight(31.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(63.0))
                            .padding(.horizontal, getRelativeWidth(54.0))
                        Text(StringConstants.kLbl125)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .padding(.leading, getRelativeWidth(16.0))
                            .padding(.vertical, getRelativeHeight(29.0))
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(360.0), height: getRelativeHeight(84.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                    bottomRight: 8.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 2))
                            .background(ColorConstants.WhiteA700)
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.horizontal, getRelativeWidth(26.0))
                        Text(StringConstants.kMsgDate)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(225.0), height: getRelativeHeight(215.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(20.0))
                            .padding(.horizontal, getRelativeWidth(89.0))
                        Divider()
                            .frame(width: getRelativeWidth(338.0), height: getRelativeHeight(1.0),
                                   alignment: .center)
                            .background(ColorConstants.Black900)
                            .padding(.top, getRelativeHeight(40.0))
                            .padding(.horizontal, getRelativeWidth(26.0))
                        Text(StringConstants.kMsgInTotalYouVe)
                            .font(FontScheme.kInterBlack(size: getRelativeHeight(25.0)))
                            .fontWeight(.black)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(363.0), height: getRelativeHeight(142.0),
                                   alignment: .topLeading)
                            .shadow(color: ColorConstants.Black9003f, radius: 4, x: 0, y: 4)
                            .padding(.top, getRelativeHeight(33.0))
                            .padding(.horizontal, getRelativeWidth(14.0))
                        VStack {
                            Text(StringConstants.kLblBack)
                                .font(FontScheme.kShortStack(size: getRelativeHeight(24.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.WhiteA700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(59.0),
                                       height: getRelativeHeight(24.0), alignment: .topLeading)
                                .padding(.vertical, getRelativeHeight(10.0))
                                .padding(.horizontal, getRelativeWidth(41.0))
                        }
                        .frame(width: getRelativeWidth(142.0), height: getRelativeHeight(45.0),
                               alignment: .center)
                        .background(ColorConstants.DeepPurpleA200)
                        .padding(.horizontal, getRelativeWidth(14.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                }
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.vertical, getRelativeHeight(12.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct EmergencyFundView_Previews: PreviewProvider {
    static var previews: some View {
        EmergencyFundView()
    }
}

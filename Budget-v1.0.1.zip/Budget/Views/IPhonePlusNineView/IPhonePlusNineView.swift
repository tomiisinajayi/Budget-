import SwiftUI

struct IPhonePlusNineView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        Image("img_line4")
                            .resizable()
                            .frame(width: getRelativeWidth(76.0), height: getRelativeWidth(76.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.horizontal, getRelativeWidth(10.0))
                        Text(StringConstants.kMsgSavingsChallen2)
                            .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.DeepPurpleA200)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(250.0), height: getRelativeHeight(115.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(8.0))
                            .padding(.horizontal, getRelativeWidth(10.0))
                        ZStack(alignment: .topLeading) {
                            Text(StringConstants.kMsgYouJustSaved2)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(298.0),
                                       height: getRelativeHeight(69.0), alignment: .center)
                                .padding(.bottom, getRelativeHeight(851.28))
                                .padding(.leading, getRelativeWidth(67.66))
                                .padding(.trailing, getRelativeWidth(64.34))
                            Image("img_medal1_474x430")
                                .resizable()
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(474.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.bottom, getRelativeHeight(718.0))
                            Text(StringConstants.kMsgYourNewSaving2)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(237.0),
                                       height: getRelativeHeight(68.0), alignment: .center)
                                .padding(.bottom, getRelativeHeight(702.18))
                                .padding(.horizontal, getRelativeWidth(96.84))
                            Image("img_trophy1")
                                .resizable()
                                .frame(width: getRelativeWidth(381.0),
                                       height: getRelativeHeight(735.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(457.0))
                                .padding(.leading, getRelativeWidth(47.0))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width,
                               height: UIScreen.main.bounds.height,
                               alignment: .topLeading)
                    }
                    .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                }
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct IPhonePlusNineView_Previews: PreviewProvider {
    static var previews: some View {
        IPhonePlusNineView()
    }
}

import SwiftUI

struct FrameSixtyNineView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            ScrollView(.vertical, showsIndicators: false) {
                VStack {
                    Text(StringConstants.kLblCrashCourse2)
                        .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                        .fontWeight(.regular)
                        .foregroundColor(ColorConstants.DeepPurpleA200)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: getRelativeWidth(342.0), height: getRelativeHeight(48.0),
                               alignment: .topLeading)
                        .padding(.top, getRelativeHeight(82.0))
                        .padding(.horizontal, getRelativeWidth(15.0))
                    ZStack(alignment: .bottomTrailing) {
                        VStack {
                            Text(StringConstants.kMsg401kAEmploye)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(16.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(145.0),
                                       height: getRelativeHeight(153.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(18.0))
                                .padding(.bottom, getRelativeHeight(17.0))
                                .padding(.horizontal, getRelativeWidth(11.0))
                        }
                        .frame(width: getRelativeWidth(189.0), height: getRelativeWidth(189.0),
                               alignment: .bottomLeading)
                        .background(ColorConstants.Bluegray100)
                        .padding(.top, getRelativeHeight(319.0))
                        .padding(.trailing, getRelativeWidth(203.0))
                        VStack {
                            Text(StringConstants.kMsgIraSimilarTo)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(16.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(157.0),
                                       height: getRelativeHeight(128.0), alignment: .center)
                                .padding(.vertical, getRelativeHeight(16.0))
                                .padding(.trailing, getRelativeWidth(25.0))
                        }
                        .frame(width: getRelativeWidth(184.0), height: getRelativeHeight(189.0),
                               alignment: .bottomTrailing)
                        .background(ColorConstants.Bluegray100)
                        .padding(.top, getRelativeHeight(319.0))
                        .padding(.leading, getRelativeWidth(207.0))
                        VStack {
                            Text(StringConstants.kMsgInvestingInv)
                                .font(FontScheme.kDomineBold(size: getRelativeHeight(19.947775)))
                                .fontWeight(.bold)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(350.0),
                                       height: getRelativeHeight(196.0), alignment: .topLeading)
                                .padding(.vertical, getRelativeHeight(11.0))
                                .padding(.horizontal, getRelativeWidth(14.0))
                        }
                        .frame(width: getRelativeWidth(396.0), height: getRelativeHeight(241.0),
                               alignment: .topLeading)
                        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                   bottomRight: 6.0)
                                .fill(ColorConstants.Orange50))
                        .padding(.bottom, getRelativeHeight(267.0))
                        ZStack(alignment: .center) {
                            Image("img_budget31_124x241")
                                .resizable()
                                .frame(width: getRelativeWidth(241.0),
                                       height: getRelativeHeight(124.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Divider()
                                .frame(width: getRelativeWidth(127.0),
                                       height: getRelativeHeight(1.0), alignment: .center)
                                .background(ColorConstants.Gray70056)
                                .padding(.bottom, getRelativeHeight(108.43))
                                .padding(.horizontal, getRelativeWidth(56.8))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(241.0), height: getRelativeHeight(124.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(232.92))
                        .padding(.horizontal, getRelativeWidth(77.0))
                    }
                    .hideNavigationBar()
                    .frame(width: getRelativeWidth(396.0), height: getRelativeHeight(508.0),
                           alignment: .center)
                    .padding(.top, getRelativeHeight(15.0))
                    .padding(.horizontal, getRelativeWidth(15.0))
                    HStack {
                        VStack {
                            Text(StringConstants.kMsgMutualFundsA)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(16.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(153.0),
                                       height: getRelativeHeight(156.0), alignment: .center)
                                .padding(.vertical, getRelativeHeight(21.0))
                                .padding(.horizontal, getRelativeWidth(12.0))
                        }
                        .frame(width: getRelativeWidth(186.0), height: getRelativeHeight(179.0),
                               alignment: .center)
                        .background(ColorConstants.Bluegray100)
                        Spacer()
                        VStack {
                            Text(StringConstants.kMsgStocksAShare)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(16.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(147.0),
                                       height: getRelativeHeight(125.0), alignment: .center)
                                .padding(.top, getRelativeHeight(25.0))
                                .padding(.bottom, getRelativeHeight(22.0))
                                .padding(.leading, getRelativeWidth(9.0))
                                .padding(.trailing, getRelativeWidth(26.0))
                        }
                        .frame(width: getRelativeWidth(184.0), height: getRelativeHeight(173.0),
                               alignment: .center)
                        .background(ColorConstants.Bluegray100)
                        .padding(.top, getRelativeHeight(6.0))
                        .padding(.leading, getRelativeWidth(14.0))
                    }
                    .frame(width: getRelativeWidth(384.0), height: getRelativeHeight(179.0),
                           alignment: .center)
                    .padding(.top, getRelativeHeight(10.0))
                    .padding(.horizontal, getRelativeWidth(15.0))
                    Button(action: {}, label: {
                        HStack(spacing: 0) {
                            Text(StringConstants.kLblBack)
                                .font(FontScheme.kInterRegular(size: getRelativeHeight(20.0)))
                                .fontWeight(.regular)
                                .padding(.horizontal, getRelativeWidth(26.0))
                                .padding(.vertical, getRelativeHeight(12.0))
                                .foregroundColor(ColorConstants.WhiteA700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(100.0),
                                       height: getRelativeHeight(45.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 22.5, topRight: 22.5,
                                                           bottomLeft: 22.5, bottomRight: 22.5)
                                        .fill(ColorConstants.DeepPurpleA200))
                                .padding(.vertical, getRelativeHeight(16.0))
                                .padding(.horizontal, getRelativeWidth(15.0))
                        }
                    })
                    .frame(width: getRelativeWidth(100.0), height: getRelativeHeight(45.0),
                           alignment: .center)
                    .background(RoundedCorners(topLeft: 22.5, topRight: 22.5, bottomLeft: 22.5,
                                               bottomRight: 22.5)
                            .fill(ColorConstants.DeepPurpleA200))
                    .padding(.vertical, getRelativeHeight(16.0))
                    .padding(.horizontal, getRelativeWidth(15.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.WhiteA700)
            }
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .hideNavigationBar()
    }
}

struct FrameSixtyNineView_Previews: PreviewProvider {
    static var previews: some View {
        FrameSixtyNineView()
    }
}

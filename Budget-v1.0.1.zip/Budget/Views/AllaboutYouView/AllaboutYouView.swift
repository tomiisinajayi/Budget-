import SwiftUI

struct AllaboutYouView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @State private var optionRadio: String = ""
    @State private var optionOneRadio: String = ""
    @State private var optionTwoRadio: String = ""
    @State private var optionThreeRadio: String = ""
    @State private var optionFourRadio: String = ""
    @State private var optionFiveRadio: String = ""
    @State private var optionSixRadio: String = ""
    @State private var optionSevenRadio: String = ""
    @State private var optionEightRadio: String = ""
    @State private var radiogroupoption: String = ""
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        Divider()
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(1.0), alignment: .leading)
                            .background(ColorConstants.Gray70056)
                        Text(StringConstants.kLblAllAboutYou)
                            .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.DeepPurpleA200)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(343.0), height: getRelativeHeight(48.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(29.0))
                            .padding(.horizontal, getRelativeWidth(29.0))
                        ZStack(alignment: .topLeading) {
                            Text(StringConstants.kMsgDoYouWork)
                                .font(FontScheme.kDomineBold(size: getRelativeHeight(20.650341)))
                                .fontWeight(.bold)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(381.0),
                                       height: getRelativeHeight(657.0), alignment: .topLeading)
                                .shadow(color: ColorConstants.Black9003f, radius: 4, x: 0, y: 4)
                            VStack(alignment: .leading, spacing: 0) {
                                RadioGroup(items: [StringConstants.kLblPartTime,
                                                   StringConstants.kLblStudent,
                                                   StringConstants.kLblNotAtAll,
                                                   StringConstants.kLblFullTime,
                                                   StringConstants.kLblYes,
                                                   StringConstants.kLblNo,
                                                   StringConstants.kLblSomewhat],
                                           selectedId: $radiogroupoption, selectedColor: Color.blue)
                                    .frame(width: getRelativeWidth(103.0),
                                           height: getRelativeHeight(429.0), alignment: .leading)
                                    .padding(.trailing)
                                RadioGroup(items: [StringConstants.kLblPartTime],
                                           selectedId: $optionRadio,
                                           selectedColor: ColorConstants.Gray700)
                                    .frame(width: getRelativeWidth(93.0),
                                           height: getRelativeHeight(16.0), alignment: .topLeading)
                                    .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                            bottomLeft: 8.0, bottomRight: 8.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 1))
                                    .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                               bottomLeft: 8.0, bottomRight: 8.0)
                                            .fill(ColorConstants.WhiteA700))
                                    .padding(.trailing, getRelativeWidth(10.0))
                                RadioGroup(items: [StringConstants.kLblStudent],
                                           selectedId: $optionOneRadio,
                                           selectedColor: ColorConstants.Gray700)
                                    .frame(width: getRelativeWidth(79.0),
                                           height: getRelativeHeight(16.0), alignment: .topLeading)
                                    .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                            bottomLeft: 8.0, bottomRight: 8.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 1))
                                    .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                               bottomLeft: 8.0, bottomRight: 8.0)
                                            .fill(ColorConstants.WhiteA700))
                                    .padding(.top, getRelativeHeight(20.0))
                                    .padding(.trailing, getRelativeWidth(24.0))
                                RadioGroup(items: [StringConstants.kLblNotAtAll],
                                           selectedId: $optionTwoRadio,
                                           selectedColor: ColorConstants.Gray700)
                                    .frame(width: getRelativeWidth(86.0),
                                           height: getRelativeHeight(17.0), alignment: .topLeading)
                                    .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                            bottomLeft: 8.0, bottomRight: 8.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 1))
                                    .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                               bottomLeft: 8.0, bottomRight: 8.0)
                                            .fill(ColorConstants.WhiteA700))
                                    .padding(.top, getRelativeHeight(22.0))
                                    .padding(.trailing, getRelativeWidth(17.0))
                                RadioGroup(items: [StringConstants.kLblFullTime],
                                           selectedId: $optionThreeRadio,
                                           selectedColor: ColorConstants.Gray700)
                                    .frame(width: getRelativeWidth(88.0),
                                           height: getRelativeHeight(16.0), alignment: .topLeading)
                                    .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                            bottomLeft: 8.0, bottomRight: 8.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 1))
                                    .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                               bottomLeft: 8.0, bottomRight: 8.0)
                                            .fill(ColorConstants.WhiteA700))
                                    .padding(.top, getRelativeHeight(23.0))
                                    .padding(.trailing, getRelativeWidth(15.0))
                                RadioGroup(items: [StringConstants.kLblYes],
                                           selectedId: $optionFourRadio,
                                           selectedColor: ColorConstants.Gray700)
                                    .frame(width: getRelativeWidth(50.0),
                                           height: getRelativeHeight(17.0), alignment: .leading)
                                    .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                            bottomLeft: 8.0, bottomRight: 8.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 1))
                                    .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                               bottomLeft: 8.0, bottomRight: 8.0)
                                            .fill(ColorConstants.WhiteA700))
                                    .padding(.top, getRelativeHeight(72.0))
                                    .padding(.trailing, getRelativeWidth(53.0))
                                RadioGroup(items: [StringConstants.kLblNo],
                                           selectedId: $optionFiveRadio,
                                           selectedColor: ColorConstants.Gray700)
                                    .frame(width: getRelativeWidth(44.0),
                                           height: getRelativeHeight(17.0),
                                           alignment: .bottomLeading)
                                    .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                            bottomLeft: 8.0, bottomRight: 8.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 1))
                                    .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                               bottomLeft: 8.0, bottomRight: 8.0)
                                            .fill(ColorConstants.WhiteA700))
                                    .padding(.top, getRelativeHeight(23.0))
                                    .padding(.trailing, getRelativeWidth(58.0))
                                RadioGroup(items: [StringConstants.kLblSomewhat],
                                           selectedId: $optionSixRadio,
                                           selectedColor: ColorConstants.Gray700)
                                    .frame(width: getRelativeWidth(103.0),
                                           height: getRelativeHeight(17.0), alignment: .center)
                                    .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                            bottomLeft: 8.0, bottomRight: 8.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 1))
                                    .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                               bottomLeft: 8.0, bottomRight: 8.0)
                                            .fill(ColorConstants.WhiteA700))
                                    .padding(.top, getRelativeHeight(25.0))
                                RadioGroup(items: [StringConstants.kLblYes],
                                           selectedId: $optionSevenRadio,
                                           selectedColor: ColorConstants.Gray700)
                                    .frame(width: getRelativeWidth(48.0),
                                           height: getRelativeHeight(17.0),
                                           alignment: .bottomLeading)
                                    .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                            bottomLeft: 8.0, bottomRight: 8.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 1))
                                    .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                               bottomLeft: 8.0, bottomRight: 8.0)
                                            .fill(ColorConstants.WhiteA700))
                                    .padding(.top, getRelativeHeight(64.0))
                                    .padding(.trailing, getRelativeWidth(54.0))
                                RadioGroup(items: [StringConstants.kLblNo],
                                           selectedId: $optionEightRadio,
                                           selectedColor: ColorConstants.Gray700)
                                    .frame(width: getRelativeWidth(43.0),
                                           height: getRelativeHeight(17.0),
                                           alignment: .bottomLeading)
                                    .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                            bottomLeft: 8.0, bottomRight: 8.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 1))
                                    .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                               bottomLeft: 8.0, bottomRight: 8.0)
                                            .fill(ColorConstants.WhiteA700))
                                    .padding(.top, getRelativeHeight(25.0))
                                    .padding(.trailing, getRelativeWidth(60.0))
                                Text(StringConstants.kLbl28000)
                                    .font(FontScheme
                                        .kInterBlack(size: getRelativeHeight(16.842106)))
                                    .fontWeight(.black)
                                    .padding(.leading, getRelativeWidth(17.0))
                                    .padding(.bottom, getRelativeHeight(7.0))
                                    .padding(.top, getRelativeHeight(10.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(289.0),
                                           height: getRelativeHeight(35.0), alignment: .leading)
                                    .overlay(RoundedCorners(topLeft: 8.98, topRight: 8.98,
                                                            bottomLeft: 8.98, bottomRight: 8.98)
                                            .stroke(ColorConstants.Bluegray100,
                                                    lineWidth: 1))
                                    .background(ColorConstants.WhiteA701)
                                    .padding(.top, getRelativeHeight(80.0))
                            }
                            .frame(width: getRelativeWidth(289.0), height: getRelativeHeight(545.0),
                                   alignment: .topLeading)
                            .padding(.bottom, getRelativeHeight(79.0))
                            .padding(.trailing, getRelativeWidth(61.0))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(381.0), height: getRelativeHeight(657.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(22.0))
                        .padding(.leading, getRelativeWidth(29.0))
                        .padding(.trailing, getRelativeWidth(20.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblSubmit)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(15.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(150.0),
                                           height: getRelativeHeight(50.0), alignment: .topLeading)
                                    .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                               bottomLeft: 10.0, bottomRight: 10.0)
                                            .fill(ColorConstants.DeepPurpleA200))
                                    .padding(.top, getRelativeHeight(22.0))
                                    .padding(.horizontal, getRelativeWidth(29.0))
                            }
                        })
                        .frame(width: getRelativeWidth(150.0), height: getRelativeHeight(50.0),
                               alignment: .topLeading)
                        .background(RoundedCorners(topLeft: 10.0, topRight: 10.0, bottomLeft: 10.0,
                                                   bottomRight: 10.0)
                                .fill(ColorConstants.DeepPurpleA200))
                        .padding(.top, getRelativeHeight(22.0))
                        .padding(.horizontal, getRelativeWidth(29.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                }
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.vertical, getRelativeHeight(80.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct AllaboutYouView_Previews: PreviewProvider {
    static var previews: some View {
        AllaboutYouView()
    }
}

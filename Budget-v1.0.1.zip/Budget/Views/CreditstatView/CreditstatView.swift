import SwiftUI

struct CreditstatView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        Text(StringConstants.kLblCrashCourse2)
                            .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.DeepPurpleA200)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(342.0), height: getRelativeHeight(48.0),
                                   alignment: .topLeading)
                            .padding(.leading, getRelativeWidth(30.0))
                            .padding(.trailing, getRelativeWidth(25.0))
                        ZStack(alignment: .topLeading) {
                            ZStack {}
                                .hideNavigationBar()
                                .frame(width: getRelativeWidth(393.0),
                                       height: getRelativeHeight(352.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                           bottomLeft: 6.0, bottomRight: 6.0)
                                        .fill(ColorConstants.Bluegray100))
                                .padding(.bottom, getRelativeHeight(344.0))
                                .padding(.horizontal, getRelativeWidth(2.0))
                            Text(StringConstants.kMsgCreditScoreA)
                                .font(FontScheme.kDomineBold(size: getRelativeHeight(19.947775)))
                                .fontWeight(.bold)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(397.0),
                                       height: getRelativeHeight(300.0), alignment: .center)
                                .padding(.bottom, getRelativeHeight(354.9))
                            VStack {
                                Text(StringConstants.kMsgHowToRaiseYo)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(18.146935)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(331.0),
                                           height: getRelativeHeight(210.0), alignment: .topLeading)
                                    .padding(.vertical, getRelativeHeight(60.0))
                                    .padding(.leading, getRelativeWidth(18.0))
                                    .padding(.trailing, getRelativeWidth(14.0))
                            }
                            .frame(width: getRelativeWidth(364.0), height: getRelativeHeight(312.0),
                                   alignment: .center)
                            .background(ColorConstants.Bluegray100)
                            .padding(.top, getRelativeHeight(384.0))
                            .padding(.leading, getRelativeWidth(15.0))
                            .padding(.trailing, getRelativeWidth(18.0))
                            ZStack(alignment: .center) {
                                Image("img_budget31_124x241")
                                    .resizable()
                                    .frame(width: getRelativeWidth(241.0),
                                           height: getRelativeHeight(124.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                Divider()
                                    .frame(width: getRelativeWidth(127.0),
                                           height: getRelativeHeight(1.0), alignment: .center)
                                    .background(ColorConstants.Gray70056)
                                    .padding(.bottom, getRelativeHeight(108.43))
                                    .padding(.horizontal, getRelativeWidth(56.8))
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(241.0), height: getRelativeHeight(124.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(349.92))
                            .padding(.leading, getRelativeWidth(76.0))
                            .padding(.trailing, getRelativeWidth(80.0))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(397.0), height: getRelativeHeight(696.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(59.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblBack)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(12.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(16.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(100.0),
                                           height: getRelativeHeight(45.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 22.5, topRight: 22.5,
                                                               bottomLeft: 22.5, bottomRight: 22.5)
                                            .fill(ColorConstants.DeepPurpleA200))
                                    .padding(.trailing, getRelativeWidth(10.0))
                            }
                        })
                        .frame(width: getRelativeWidth(100.0), height: getRelativeHeight(45.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 22.5, topRight: 22.5, bottomLeft: 22.5,
                                                   bottomRight: 22.5)
                                .fill(ColorConstants.DeepPurpleA200))
                        .padding(.trailing, getRelativeWidth(10.0))
                    }
                    .frame(width: getRelativeWidth(398.0), alignment: .topLeading)
                }
            }
            .frame(width: getRelativeWidth(398.0), alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.vertical, getRelativeHeight(63.0))
            .padding(.horizontal, getRelativeWidth(15.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct CreditstatView_Previews: PreviewProvider {
    static var previews: some View {
        CreditstatView()
    }
}

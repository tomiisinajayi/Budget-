import SwiftUI

struct CrashCourseView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                VStack(alignment: .leading, spacing: 0) {
                    HStack {
                        ZStack(alignment: .topLeading) {
                            Text(StringConstants.kLblCrashCourse2)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(342.0),
                                       height: getRelativeHeight(48.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(75.48))
                                .padding(.leading, getRelativeWidth(45.25))
                            Image("img_icons8openmen_76x67")
                                .resizable()
                                .frame(width: getRelativeWidth(67.0),
                                       height: getRelativeHeight(76.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.bottom, getRelativeHeight(47.0))
                                .padding(.trailing, getRelativeWidth(321.0))
                        }
                        .hideNavigationBar()
                    }
                    .frame(width: getRelativeWidth(388.0), height: getRelativeHeight(123.0),
                           alignment: .leading)
                    .padding(.trailing)
                }
                .frame(width: getRelativeWidth(423.0), height: getRelativeHeight(123.0),
                       alignment: .leading)
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kMsgIncreaseYourF)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(19.581396)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(410.0), height: getRelativeHeight(125.0),
                                   alignment: .center)
                        Text(StringConstants.kMsgClickToLearn)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(27.081455)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(307.0), height: getRelativeHeight(27.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(60.0))
                            .padding(.horizontal, getRelativeWidth(42.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblCreditScore3)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(27.081455)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(24.0))
                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(395.0),
                                           height: getRelativeHeight(76.0), alignment: .topLeading)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Bluegray100))
                                    .padding(.top, getRelativeHeight(51.0))
                                    .padding(.trailing, getRelativeWidth(12.0))
                            }
                        })
                        .frame(width: getRelativeWidth(395.0), height: getRelativeHeight(76.0),
                               alignment: .topLeading)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Bluegray100))
                        .padding(.top, getRelativeHeight(51.0))
                        .padding(.trailing, getRelativeWidth(12.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblSavings)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(26.960556)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(24.0))
                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(395.0),
                                           height: getRelativeHeight(76.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Bluegray100))
                                    .padding(.top, getRelativeHeight(23.0))
                                    .padding(.trailing, getRelativeWidth(12.0))
                            }
                        })
                        .frame(width: getRelativeWidth(395.0), height: getRelativeHeight(76.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Bluegray100))
                        .padding(.top, getRelativeHeight(23.0))
                        .padding(.trailing, getRelativeWidth(12.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblBudgeting)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(27.081455)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(24.0))
                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(395.0),
                                           height: getRelativeHeight(76.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Bluegray100))
                                    .padding(.top, getRelativeHeight(23.0))
                                    .padding(.trailing, getRelativeWidth(12.0))
                            }
                        })
                        .frame(width: getRelativeWidth(395.0), height: getRelativeHeight(76.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Bluegray100))
                        .padding(.top, getRelativeHeight(23.0))
                        .padding(.trailing, getRelativeWidth(12.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblInvestments)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(27.081455)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(24.0))
                                    .foregroundColor(ColorConstants.DeepPurpleA200)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(395.0),
                                           height: getRelativeHeight(76.0), alignment: .topLeading)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Bluegray100))
                                    .padding(.top, getRelativeHeight(23.0))
                                    .padding(.trailing, getRelativeWidth(12.0))
                            }
                        })
                        .frame(width: getRelativeWidth(395.0), height: getRelativeHeight(76.0),
                               alignment: .topLeading)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Bluegray100))
                        .padding(.top, getRelativeHeight(23.0))
                        .padding(.trailing, getRelativeWidth(12.0))
                    }
                    .frame(width: getRelativeWidth(410.0), height: getRelativeHeight(637.0),
                           alignment: .center)
                    .background(ColorConstants.WhiteA700)
                    .padding(.leading, getRelativeWidth(12.0))
                }
                .frame(width: getRelativeWidth(423.0), height: getRelativeHeight(637.0),
                       alignment: .leading)
                .padding(.top, getRelativeHeight(50.0))
            }
            .frame(width: getRelativeWidth(423.0), alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.vertical, getRelativeHeight(42.0))
            .padding(.trailing, getRelativeWidth(6.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct CrashCourseView_Previews: PreviewProvider {
    static var previews: some View {
        CrashCourseView()
    }
}

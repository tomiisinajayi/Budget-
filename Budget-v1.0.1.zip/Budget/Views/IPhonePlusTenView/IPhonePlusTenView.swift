import SwiftUI

struct IPhonePlusTenView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            ZStack {
                ScrollView(.vertical, showsIndicators: false) {
                    ZStack(alignment: .topLeading) {
                        VStack {
                            Text(StringConstants.kMsgSavingsChallen2)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(250.0),
                                       height: getRelativeHeight(115.0), alignment: .center)
                            Text(StringConstants.kMsgYouJustSaved)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(248.0),
                                       height: getRelativeHeight(129.0), alignment: .center)
                                .padding(.top, getRelativeHeight(311.0))
                                .padding(.trailing, getRelativeWidth(4.0))
                            Text(StringConstants.kMsgYourNewSaving)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(237.0),
                                       height: getRelativeHeight(68.0), alignment: .center)
                                .padding(.top, getRelativeHeight(50.0))
                                .padding(.horizontal, getRelativeWidth(8.0))
                        }
                        .frame(width: getRelativeWidth(252.0), height: getRelativeHeight(674.0),
                               alignment: .center)
                        .padding(.bottom, getRelativeHeight(3377.0))
                        .padding(.horizontal, getRelativeWidth(89.35))
                        Image("img_line4")
                            .resizable()
                            .frame(width: getRelativeWidth(76.0), height: getRelativeWidth(76.0),
                                   alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.bottom, getRelativeHeight(4058.0))
                            .padding(.trailing, getRelativeWidth(344.0))
                        VStack {
                            Image("img_trophy1")
                                .resizable()
                                .frame(width: getRelativeWidth(342.0),
                                       height: getRelativeHeight(701.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(711.0))
                                .padding(.horizontal, getRelativeWidth(12.0))
                            Image("img_medal1")
                                .resizable()
                                .frame(width: UIScreen.main.bounds.width,
                                       height: UIScreen.main.bounds.height,
                                       alignment: .topLeading)
                                .scaledToFit()
                                .clipped()
                        }
                        .frame(width: UIScreen.main.bounds.width,
                               height: UIScreen.main.bounds.height,
                               alignment: .topLeading)
                        .overlay(RoundedCorners(topLeft: 5.0, topRight: 5.0, bottomLeft: 5.0,
                                                bottomRight: 5.0)
                                .stroke(ColorConstants.DeepPurpleA202,
                                        lineWidth: 1))
                        .background(RoundedCorners(topLeft: 5.0, topRight: 5.0, bottomLeft: 5.0,
                                                   bottomRight: 5.0)
                                .fill(Color.clear.opacity(0.7)))
                    }
                    .hideNavigationBar()
                    .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height,
                           alignment: .topLeading)
                }
            }
            .hideNavigationBar()
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct IPhonePlusTenView_Previews: PreviewProvider {
    static var previews: some View {
        IPhonePlusTenView()
    }
}

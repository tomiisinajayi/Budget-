import SwiftUI

struct SavingsView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                HStack {
                    ZStack(alignment: .leading) {
                        Text(StringConstants.kLblSavings)
                            .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.DeepPurpleA200)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(203.0), height: getRelativeHeight(48.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(25.8))
                            .padding(.horizontal, getRelativeWidth(113.63))
                        ZStack(alignment: .leading) {
                            Divider()
                                .frame(width: getRelativeWidth(427.0),
                                       height: getRelativeHeight(1.0), alignment: .center)
                                .background(ColorConstants.Gray70056)
                                .padding(.bottom, getRelativeHeight(65.09))
                                .padding(.horizontal, getRelativeWidth(2.98))
                            Image("img_line4")
                                .resizable()
                                .frame(width: getRelativeWidth(76.0),
                                       height: getRelativeWidth(76.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.trailing, getRelativeWidth(354.0))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(76.0),
                               alignment: .leading)
                    }
                    .hideNavigationBar()
                }
                .frame(width: UIScreen.main.bounds.width - 20, height: getRelativeHeight(76.0),
                       alignment: .leading)
                VStack {
                    VStack {
                        Text(StringConstants.kLblEmergencyFund)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(119.0), height: getRelativeHeight(61.0),
                                   alignment: .center)
                            .padding(.vertical, getRelativeHeight(28.0))
                            .padding(.horizontal, getRelativeWidth(70.0))
                    }
                    .frame(width: getRelativeWidth(265.0), height: getRelativeHeight(118.0),
                           alignment: .center)
                    .overlay(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                            bottomRight: 20.0)
                            .stroke(ColorConstants.Purple900,
                                    lineWidth: 1))
                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                               bottomRight: 20.0)
                            .fill(Color.clear.opacity(0.7)))
                    VStack {
                        Text(StringConstants.kMsgLongTermSavin)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(194.0), height: getRelativeHeight(25.0),
                                   alignment: .topLeading)
                            .padding(.vertical, getRelativeHeight(48.0))
                            .padding(.horizontal, getRelativeWidth(35.0))
                    }
                    .frame(width: getRelativeWidth(265.0), height: getRelativeHeight(118.0),
                           alignment: .center)
                    .overlay(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                            bottomRight: 20.0)
                            .stroke(ColorConstants.Purple900,
                                    lineWidth: 1))
                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                               bottomRight: 20.0)
                            .fill(Color.clear.opacity(0.7)))
                    .padding(.top, getRelativeHeight(89.0))
                    VStack {
                        Text(StringConstants.kMsgSavingsChalle)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900E5)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(105.0), height: getRelativeHeight(66.0),
                                   alignment: .center)
                            .padding(.vertical, getRelativeHeight(28.0))
                            .padding(.horizontal, getRelativeWidth(79.0))
                    }
                    .frame(width: getRelativeWidth(265.0), height: getRelativeHeight(118.0),
                           alignment: .center)
                    .overlay(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                            bottomRight: 20.0)
                            .stroke(ColorConstants.Purple900,
                                    lineWidth: 1))
                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                               bottomRight: 20.0)
                            .fill(Color.clear.opacity(0.7)))
                    .padding(.top, getRelativeHeight(100.0))
                }
                .frame(width: getRelativeWidth(266.0), height: getRelativeHeight(543.0),
                       alignment: .center)
                .background(ColorConstants.WhiteA700)
                .padding(.top, getRelativeHeight(63.0))
                .padding(.horizontal, getRelativeWidth(83.0))
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.vertical, getRelativeHeight(71.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct SavingsView_Previews: PreviewProvider {
    static var previews: some View {
        SavingsView()
    }
}

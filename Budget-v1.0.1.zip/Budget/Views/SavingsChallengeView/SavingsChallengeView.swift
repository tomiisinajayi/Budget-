import SwiftUI

struct SavingsChallengeView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        Group {
                            Image("img_line4")
                                .resizable()
                                .frame(width: getRelativeWidth(76.0),
                                       height: getRelativeWidth(76.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.trailing, getRelativeWidth(10.0))
                            Text(StringConstants.kMsgSavingsChallen)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(250.0),
                                       height: getRelativeHeight(115.0), alignment: .center)
                                .padding(.horizontal, getRelativeWidth(53.0))
                            Text(StringConstants.kMsgEnterYourSavi)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(20.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(354.0),
                                       height: getRelativeHeight(91.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(69.0))
                                .padding(.leading, getRelativeWidth(30.0))
                            Text(StringConstants.kLblSaving)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Bluegray700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(79.0),
                                       height: getRelativeHeight(25.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(67.0))
                                .padding(.horizontal, getRelativeWidth(24.0))
                            Text(StringConstants.kLbl5002)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .padding(.leading, getRelativeWidth(16.0))
                                .padding(.vertical, getRelativeHeight(30.0))
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(360.0),
                                       height: getRelativeHeight(99.0), alignment: .leading)
                                .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                        bottomLeft: 8.0,
                                                        bottomRight: 8.0)
                                        .stroke(ColorConstants.Bluegray100,
                                                lineWidth: 2))
                                .background(ColorConstants.WhiteA700)
                                .padding(.top, getRelativeHeight(6.0))
                                .padding(.leading, getRelativeWidth(24.0))
                            Text(StringConstants.kLblFor)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Bluegray700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(43.0),
                                       height: getRelativeHeight(25.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(16.0))
                                .padding(.horizontal, getRelativeWidth(25.0))
                            Text(StringConstants.kLblTripToParis)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .padding(.leading, getRelativeWidth(16.0))
                                .padding(.bottom, getRelativeHeight(28.0))
                                .padding(.top, getRelativeHeight(30.0))
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(360.0),
                                       height: getRelativeHeight(84.0), alignment: .leading)
                                .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                        bottomLeft: 8.0,
                                                        bottomRight: 8.0)
                                        .stroke(ColorConstants.Bluegray100,
                                                lineWidth: 2))
                                .background(ColorConstants.WhiteA700)
                                .padding(.top, getRelativeHeight(6.0))
                                .padding(.leading, getRelativeWidth(24.0))
                            Text(StringConstants.kMsgDaysToComplet)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Bluegray700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(198.0),
                                       height: getRelativeHeight(27.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(25.0))
                                .padding(.horizontal, getRelativeWidth(25.0))
                        }
                        Group {
                            VStack {
                                Text(StringConstants.kLbl90)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(30.0),
                                           height: getRelativeHeight(25.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(27.0))
                                    .padding(.bottom, getRelativeHeight(26.0))
                                    .padding(.horizontal, getRelativeWidth(16.0))
                            }
                            .frame(width: getRelativeWidth(360.0), height: getRelativeHeight(79.0),
                                   alignment: .trailing)
                            .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                    bottomRight: 8.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 2))
                            .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                       bottomRight: 8.0)
                                    .fill(ColorConstants.WhiteA700))
                            .padding(.leading, getRelativeWidth(10.0))
                            Button(action: {}, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLblCalculate)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .padding(.horizontal, getRelativeWidth(21.0))
                                        .padding(.vertical, getRelativeHeight(10.0))
                                        .foregroundColor(ColorConstants.WhiteA700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(142.0),
                                               height: getRelativeHeight(45.0),
                                               alignment: .topLeading)
                                        .background(ColorConstants.DeepPurpleA200)
                                        .padding(.top, getRelativeHeight(27.0))
                                        .padding(.horizontal, getRelativeWidth(110.0))
                                }
                            })
                            .frame(width: getRelativeWidth(142.0), height: getRelativeHeight(45.0),
                                   alignment: .topLeading)
                            .background(ColorConstants.DeepPurpleA200)
                            .padding(.top, getRelativeHeight(27.0))
                            .padding(.horizontal, getRelativeWidth(110.0))
                        }
                    }
                    .frame(width: getRelativeWidth(385.0), alignment: .topLeading)
                }
            }
            .frame(width: getRelativeWidth(385.0), alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.bottom, getRelativeHeight(44.0))
            .padding(.leading, getRelativeWidth(10.0))
            .padding(.trailing, getRelativeWidth(35.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct SavingsChallengeView_Previews: PreviewProvider {
    static var previews: some View {
        SavingsChallengeView()
    }
}

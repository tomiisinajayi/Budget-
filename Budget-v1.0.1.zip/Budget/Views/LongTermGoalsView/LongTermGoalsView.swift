import SwiftUI

struct LongTermGoalsView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                VStack {
                    HStack {
                        ZStack(alignment: .topLeading) {
                            Text(StringConstants.kLblLongTermGoals)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(45.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(407.0),
                                       height: getRelativeHeight(45.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(51.82))
                            Image("img_icons8openmen_73x76")
                                .resizable()
                                .frame(width: getRelativeWidth(76.0),
                                       height: getRelativeHeight(73.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.bottom, getRelativeHeight(23.0))
                                .padding(.trailing, getRelativeWidth(330.65))
                        }
                        .hideNavigationBar()
                    }
                    .frame(width: getRelativeWidth(407.0), height: getRelativeHeight(96.0),
                           alignment: .leading)
                    .padding(.leading, getRelativeWidth(9.0))
                    .padding(.trailing, getRelativeWidth(12.0))
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(96.0),
                       alignment: .leading)
                VStack(alignment: .leading, spacing: 0) {
                    VStack {
                        Text(StringConstants.kLblSavingFor)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(15.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Purple700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(79.0), height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(29.0))
                        Text(StringConstants.kMsg2023HondaCivi)
                            .font(FontScheme.kDomineBold(size: getRelativeHeight(15.0)))
                            .fontWeight(.bold)
                            .padding(.leading, getRelativeWidth(16.0))
                            .padding(.bottom, getRelativeHeight(17.0))
                            .padding(.top, getRelativeHeight(15.0))
                            .foregroundColor(ColorConstants.Black90087)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(360.0), height: getRelativeHeight(48.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                    bottomRight: 8.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 2))
                            .background(ColorConstants.WhiteA700)
                            .padding(.top, getRelativeHeight(5.0))
                            .padding(.horizontal, getRelativeWidth(22.0))
                        Text(StringConstants.kLblBudget2)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(15.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Purple700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(58.0), height: getRelativeHeight(17.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(30.0))
                            .padding(.horizontal, getRelativeWidth(32.0))
                        Text(StringConstants.kLbl26000)
                            .font(FontScheme.kDomineBold(size: getRelativeHeight(15.0)))
                            .fontWeight(.bold)
                            .padding(.leading, getRelativeWidth(16.0))
                            .padding(.vertical, getRelativeHeight(16.0))
                            .foregroundColor(ColorConstants.Black90087)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(360.0), height: getRelativeHeight(48.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                    bottomRight: 8.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 2))
                            .background(ColorConstants.WhiteA700)
                            .shadow(color: ColorConstants.Black9003f, radius: 4, x: 0, y: 4)
                            .padding(.top, getRelativeHeight(8.0))
                            .padding(.horizontal, getRelativeWidth(22.0))
                        ZStack(alignment: .center) {
                            Image("img_budget191")
                                .resizable()
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(389.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                            VStack {
                                Text(StringConstants.kLblCongratulations)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(40.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(355.0),
                                           height: getRelativeHeight(40.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(10.0))
                                Text(StringConstants.kMsgYouJustGot3)
                                    .font(FontScheme.kInterBlack(size: getRelativeHeight(15.0)))
                                    .fontWeight(.black)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(308.0),
                                           height: getRelativeHeight(85.0), alignment: .center)
                                    .padding(.top, getRelativeHeight(100.0))
                                    .padding(.horizontal, getRelativeWidth(10.0))
                                Text(StringConstants.kMsgYouVeSaved39)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(35.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(387.0),
                                           height: getRelativeHeight(88.0), alignment: .center)
                                    .padding(.top, getRelativeHeight(38.0))
                            }
                            .frame(width: getRelativeWidth(387.0), height: getRelativeHeight(352.0),
                                   alignment: .center)
                            .padding(.vertical, getRelativeHeight(21.06))
                            .padding(.horizontal, getRelativeWidth(22.33))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(389.0),
                               alignment: .leading)
                        .padding(.top, getRelativeHeight(42.0))
                        Text(StringConstants.kLbl10127)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(48.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(174.0), height: getRelativeHeight(48.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(22.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblBack)
                                    .font(FontScheme.kShortStack(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(7.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(161.0),
                                           height: getRelativeHeight(40.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 5.0, topRight: 5.0,
                                                               bottomLeft: 5.0, bottomRight: 5.0)
                                            .fill(ColorConstants.DeepPurpleA200))
                                    .padding(.top, getRelativeHeight(71.0))
                                    .padding(.horizontal, getRelativeWidth(22.0))
                            }
                        })
                        .frame(width: getRelativeWidth(161.0), height: getRelativeHeight(40.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 5.0, topRight: 5.0, bottomLeft: 5.0,
                                                   bottomRight: 5.0)
                                .fill(ColorConstants.DeepPurpleA200))
                        .padding(.top, getRelativeHeight(71.0))
                        .padding(.horizontal, getRelativeWidth(22.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(766.0),
                           alignment: .leading)
                    .background(ColorConstants.WhiteA700)
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(766.0),
                       alignment: .leading)
                .padding(.top, getRelativeHeight(38.0))
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.bottom, getRelativeHeight(30.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct LongTermGoalsView_Previews: PreviewProvider {
    static var previews: some View {
        LongTermGoalsView()
    }
}

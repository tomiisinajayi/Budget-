import SwiftUI

struct WelcomePageView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        ZStack(alignment: .topLeading) {
                            Image("img_budget31")
                                .resizable()
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(417.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Divider()
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(1.0), alignment: .topLeading)
                                .background(ColorConstants.Gray70056)
                                .padding(.bottom, getRelativeHeight(367.0))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(417.0),
                               alignment: .leading)
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblGetStarted)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(30.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(18.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(347.0),
                                           height: getRelativeHeight(66.0), alignment: .topLeading)
                                    .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                               bottomLeft: 10.0, bottomRight: 10.0)
                                            .fill(ColorConstants.DeepPurpleA200))
                                    .padding(.top, getRelativeHeight(14.0))
                                    .padding(.leading, getRelativeWidth(49.0))
                                    .padding(.trailing, getRelativeWidth(34.0))
                            }
                        })
                        .frame(width: getRelativeWidth(347.0), height: getRelativeHeight(66.0),
                               alignment: .topLeading)
                        .background(RoundedCorners(topLeft: 10.0, topRight: 10.0, bottomLeft: 10.0,
                                                   bottomRight: 10.0)
                                .fill(ColorConstants.DeepPurpleA200))
                        .padding(.top, getRelativeHeight(14.0))
                        .padding(.leading, getRelativeWidth(49.0))
                        .padding(.trailing, getRelativeWidth(34.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgIAlreadyHave)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(21.0))
                                    .padding(.vertical, getRelativeHeight(20.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(347.0),
                                           height: getRelativeHeight(66.0), alignment: .topLeading)
                                    .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                               bottomLeft: 10.0, bottomRight: 10.0)
                                            .fill(ColorConstants.Black9003f))
                                    .padding(.top, getRelativeHeight(29.0))
                                    .padding(.leading, getRelativeWidth(49.0))
                                    .padding(.trailing, getRelativeWidth(34.0))
                            }
                        })
                        .frame(width: getRelativeWidth(347.0), height: getRelativeHeight(66.0),
                               alignment: .topLeading)
                        .background(RoundedCorners(topLeft: 10.0, topRight: 10.0, bottomLeft: 10.0,
                                                   bottomRight: 10.0)
                                .fill(ColorConstants.Black9003f))
                        .padding(.top, getRelativeHeight(29.0))
                        .padding(.leading, getRelativeWidth(49.0))
                        .padding(.trailing, getRelativeWidth(34.0))
                        ZStack(alignment: .bottomTrailing) {
                            VStack {
                                Text(StringConstants.kLblBudget)
                                    .font(FontScheme.kDomineRegular(size: getRelativeHeight(40.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(188.0),
                                           height: getRelativeHeight(40.0), alignment: .center)
                                Text(StringConstants.kLblByGrape)
                                    .font(FontScheme.kDomineRegular(size: getRelativeHeight(35.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(155.0),
                                           height: getRelativeHeight(35.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(16.0))
                            }
                            .frame(width: getRelativeWidth(188.0), height: getRelativeHeight(78.0),
                                   alignment: .topLeading)
                            .padding(.bottom, getRelativeHeight(98.0))
                            Image("img_image1")
                                .resizable()
                                .frame(width: getRelativeWidth(108.0),
                                       height: getRelativeHeight(113.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(63.38))
                                .padding(.leading, getRelativeWidth(47.08))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(188.0), height: getRelativeHeight(176.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(121.0))
                        .padding(.horizontal, getRelativeWidth(49.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                }
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.top, getRelativeHeight(60.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct WelcomePageView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomePageView()
    }
}

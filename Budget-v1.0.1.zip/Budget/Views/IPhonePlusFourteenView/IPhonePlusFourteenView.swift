import SwiftUI

struct IPhonePlusFourteenView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                VStack(alignment: .leading, spacing: 0) {
                    VStack {
                        HStack {
                            Image("img_line4")
                                .resizable()
                                .frame(width: getRelativeWidth(76.0),
                                       height: getRelativeWidth(76.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.bottom, getRelativeHeight(180.0))
                            ZStack {
                                Image("img_scott1")
                                    .resizable()
                                    .frame(width: getRelativeWidth(139.0),
                                           height: getRelativeHeight(169.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.leading, getRelativeWidth(27.97))
                                    .padding(.trailing, getRelativeWidth(14.03))
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(181.0), height: getRelativeHeight(186.0),
                                   alignment: .bottom)
                            .background(RoundedCorners(topLeft: 55.0, topRight: 55.0,
                                                       bottomLeft: 55.0, bottomRight: 55.0)
                                    .fill(ColorConstants.Bluegray100))
                            .padding(.top, getRelativeHeight(70.0))
                            .padding(.leading, getRelativeWidth(39.0))
                        }
                        .frame(width: getRelativeWidth(296.0), height: getRelativeHeight(256.0),
                               alignment: .leading)
                        .padding(.trailing, getRelativeWidth(10.0))
                        Text(StringConstants.kMsgTheoneandonly)
                            .font(FontScheme.kNunitoBold(size: getRelativeHeight(23.0)))
                            .fontWeight(.bold)
                            .foregroundColor(ColorConstants.DeepPurpleA200)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(222.0), height: getRelativeHeight(23.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(9.0))
                            .padding(.leading, getRelativeWidth(10.0))
                        Text(StringConstants.kMsgNameScottRot)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(24.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(247.0), height: getRelativeHeight(278.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(95.0))
                            .padding(.leading, getRelativeWidth(75.0))
                        Text(StringConstants.kLblLinkedCard)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(20.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(104.0), height: getRelativeHeight(20.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(48.0))
                            .padding(.horizontal, getRelativeWidth(79.0))
                    }
                    .frame(width: getRelativeWidth(324.0), height: getRelativeHeight(731.0),
                           alignment: .leading)
                    .padding(.trailing)
                }
                .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(731.0),
                       alignment: .leading)
                .padding(.horizontal, getRelativeWidth(8.0))
                VStack(alignment: .trailing, spacing: 0) {
                    Divider()
                        .frame(width: getRelativeWidth(300.0), height: getRelativeHeight(1.0),
                               alignment: .trailing)
                        .background(ColorConstants.Black900)
                        .padding(.leading)
                        .padding(.leading)
                    VStack {
                        Text(StringConstants.kLblVisaDebit3456)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(23.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(158.0), height: getRelativeHeight(23.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(12.0))
                            .padding(.horizontal, getRelativeWidth(18.0))
                        Text(StringConstants.kLbl03192023)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(15.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(84.0), height: getRelativeHeight(15.0),
                                   alignment: .topLeading)
                            .padding(.vertical, getRelativeHeight(8.0))
                            .padding(.horizontal, getRelativeWidth(40.0))
                    }
                    .frame(width: getRelativeWidth(300.0), height: getRelativeHeight(75.0),
                           alignment: .trailing)
                    .background(RoundedCorners(topLeft: 10.0, topRight: 10.0, bottomLeft: 10.0,
                                               bottomRight: 10.0)
                            .fill(ColorConstants.Bluegray100))
                    .padding(.top, getRelativeHeight(12.0))
                    .padding(.leading, getRelativeWidth(10.0))
                }
                .frame(width: getRelativeWidth(375.0), height: getRelativeHeight(88.0),
                       alignment: .leading)
                .padding(.vertical, getRelativeHeight(20.0))
                .padding(.horizontal, getRelativeWidth(8.0))
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct IPhonePlusFourteenView_Previews: PreviewProvider {
    static var previews: some View {
        IPhonePlusFourteenView()
    }
}

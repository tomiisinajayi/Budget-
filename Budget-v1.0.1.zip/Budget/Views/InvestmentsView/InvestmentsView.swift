import SwiftUI

struct InvestmentsView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack(alignment: .leading, spacing: 0) {
                VStack(alignment: .leading, spacing: 0) {
                    HStack {
                        ZStack(alignment: .topLeading) {
                            Text(StringConstants.kLblInvestSmart2)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(48.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(352.0),
                                       height: getRelativeHeight(48.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(69.39))
                                .padding(.leading, getRelativeWidth(40.95))
                            Image("img_line4")
                                .resizable()
                                .frame(width: getRelativeWidth(76.0),
                                       height: getRelativeWidth(76.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.bottom, getRelativeHeight(41.0))
                                .padding(.trailing, getRelativeWidth(317.0))
                        }
                        .hideNavigationBar()
                    }
                    .frame(width: getRelativeWidth(393.0), height: getRelativeHeight(117.0),
                           alignment: .leading)
                    .padding(.trailing)
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(117.0),
                       alignment: .leading)
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kMsgNetBalance4)
                            .font(FontScheme.kDomineRegular(size: getRelativeHeight(18.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(220.0), height: getRelativeHeight(81.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(23.0))
                        HStack {
                            VStack {
                                Text(StringConstants.kMsgToday18634)
                                    .font(FontScheme
                                        .kShrikhandRegular(size: getRelativeHeight(23.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(104.0),
                                           height: getRelativeHeight(89.0), alignment: .center)
                                    .padding(.vertical, getRelativeHeight(16.0))
                                    .padding(.leading, getRelativeWidth(8.0))
                                    .padding(.trailing, getRelativeWidth(11.0))
                            }
                            .frame(width: getRelativeWidth(125.0), height: getRelativeHeight(122.0),
                                   alignment: .center)
                            .background(ColorConstants.Green701)
                            VStack {
                                Text(StringConstants.kMsgTotal78667)
                                    .font(FontScheme
                                        .kShrikhandRegular(size: getRelativeHeight(23.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(107.0),
                                           height: getRelativeHeight(89.0), alignment: .center)
                                    .padding(.vertical, getRelativeHeight(16.0))
                                    .padding(.horizontal, getRelativeWidth(5.0))
                            }
                            .frame(width: getRelativeWidth(119.0), height: getRelativeHeight(122.0),
                                   alignment: .center)
                            .background(ColorConstants.Green700)
                            .padding(.leading, getRelativeWidth(8.0))
                            VStack {
                                Text(StringConstants.kLblTopStockAapl)
                                    .font(FontScheme
                                        .kShrikhandRegular(size: getRelativeHeight(24.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(80.0),
                                           height: getRelativeHeight(88.0), alignment: .center)
                                    .padding(.vertical, getRelativeHeight(18.0))
                                    .padding(.leading, getRelativeWidth(22.0))
                                    .padding(.trailing, getRelativeWidth(19.0))
                            }
                            .frame(width: getRelativeWidth(123.0), height: getRelativeHeight(121.0),
                                   alignment: .center)
                            .background(ColorConstants.Bluegray100)
                            .padding(.leading, getRelativeWidth(8.0))
                            Spacer()
                        }
                        .frame(width: getRelativeWidth(383.0), height: getRelativeHeight(122.0),
                               alignment: .leading)
                        .padding(.horizontal, getRelativeWidth(19.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblDetails)
                                    .font(FontScheme.kShortStack(size: getRelativeHeight(24.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(10.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(358.0),
                                           height: getRelativeHeight(44.0), alignment: .center)
                                    .background(ColorConstants.DeepPurpleA200)
                                    .padding(.top, getRelativeHeight(17.0))
                                    .padding(.horizontal, getRelativeWidth(23.0))
                            }
                        })
                        .frame(width: getRelativeWidth(358.0), height: getRelativeHeight(44.0),
                               alignment: .center)
                        .background(ColorConstants.DeepPurpleA200)
                        .padding(.top, getRelativeHeight(17.0))
                        .padding(.horizontal, getRelativeWidth(23.0))
                        HStack {
                            Button(action: {}, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLblSym)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(25.0)))
                                        .fontWeight(.regular)
                                        .padding(.trailing, getRelativeWidth(9.0))
                                        .padding(.leading, getRelativeWidth(14.0))
                                        .padding(.vertical, getRelativeHeight(6.0))
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(77.0),
                                               height: getRelativeHeight(37.0),
                                               alignment: .topLeading)
                                        .overlay(RoundedCorners()
                                            .stroke(ColorConstants.DeepPurpleA200, lineWidth: 3))
                                        .background(RoundedCorners().fill(Color.clear.opacity(0.7)))
                                }
                            })
                            .frame(width: getRelativeWidth(77.0), height: getRelativeHeight(37.0),
                                   alignment: .topLeading)
                            .overlay(RoundedCorners()
                                .stroke(ColorConstants.DeepPurpleA200, lineWidth: 3))
                            .background(RoundedCorners().fill(Color.clear.opacity(0.7)))
                            Text(StringConstants.kLblPrices)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(30.0)))
                                .fontWeight(.regular)
                                .padding(.horizontal, getRelativeWidth(30.0))
                                .padding(.vertical, getRelativeHeight(1.0))
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(298.0),
                                       height: getRelativeHeight(37.0), alignment: .center)
                                .overlay(RoundedCorners()
                                    .stroke(ColorConstants.DeepPurpleA200, lineWidth: 3))
                                .background(RoundedCorners().fill(Color.clear.opacity(0.7)))
                                .padding(.leading, getRelativeWidth(13.0))
                        }
                        .frame(width: getRelativeWidth(388.0), height: getRelativeHeight(37.0),
                               alignment: .leading)
                        .padding(.top, getRelativeHeight(21.0))
                        .padding(.horizontal, getRelativeWidth(22.0))
                        ZStack(alignment: .bottomLeading) {
                            VStack(alignment: .leading, spacing: 0) {
                                HStack {
                                    Text(StringConstants.kLblAapl)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(57.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                    Spacer()
                                    Text(StringConstants.kLbl201134)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Green700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(106.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(131.0))
                                }
                                .frame(width: getRelativeWidth(295.0),
                                       height: getRelativeHeight(27.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(22.0))
                                .padding(.horizontal, getRelativeWidth(14.0))
                                HStack {
                                    Text(StringConstants.kLblAmzn)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(65.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.bottom, getRelativeHeight(17.0))
                                    Spacer()
                                    Text(StringConstants.kLbl114509)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Green700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(108.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(17.0))
                                        .padding(.leading, getRelativeWidth(125.0))
                                }
                                .frame(width: getRelativeWidth(300.0),
                                       height: getRelativeHeight(41.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(29.0))
                                .padding(.horizontal, getRelativeWidth(9.0))
                                HStack {
                                    Text(StringConstants.kLblBby)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(42.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                    Spacer()
                                    Text(StringConstants.kLbl5423)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.RedA700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(90.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(154.0))
                                }
                                .frame(width: getRelativeWidth(288.0),
                                       height: getRelativeHeight(26.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(32.0))
                                .padding(.horizontal, getRelativeWidth(17.0))
                                HStack {
                                    Text(StringConstants.kLblWmt)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(51.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                    Spacer()
                                    Text(StringConstants.kLbl7012)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.RedA700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(86.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(150.0))
                                }
                                .frame(width: getRelativeWidth(288.0),
                                       height: getRelativeHeight(24.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(42.0))
                                .padding(.horizontal, getRelativeWidth(14.0))
                                HStack {
                                    Text(StringConstants.kLblCmg)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(48.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                    Spacer()
                                    Text(StringConstants.kLbl124570)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Green700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(104.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(135.0))
                                }
                                .frame(width: getRelativeWidth(289.0),
                                       height: getRelativeHeight(26.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(33.0))
                                .padding(.horizontal, getRelativeWidth(13.0))
                                HStack {
                                    Text(StringConstants.kLblMslh)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(62.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.bottom, getRelativeHeight(5.0))
                                    Spacer()
                                    Text(StringConstants.kLbl90744)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Green700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(96.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(5.0))
                                        .padding(.leading, getRelativeWidth(132.0))
                                }
                                .frame(width: getRelativeWidth(290.0),
                                       height: getRelativeHeight(29.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(31.0))
                                .padding(.leading, getRelativeWidth(7.0))
                                .padding(.trailing, getRelativeWidth(10.0))
                                HStack {
                                    Text(StringConstants.kLblTgt)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(38.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(6.0))
                                    Spacer()
                                    Text(StringConstants.kLbl6452)
                                        .font(FontScheme
                                            .kSrirachaRegular(size: getRelativeHeight(24.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.RedA700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(89.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.bottom, getRelativeHeight(6.0))
                                        .padding(.leading, getRelativeWidth(128.0))
                                }
                                .frame(width: getRelativeWidth(256.0),
                                       height: getRelativeHeight(30.0), alignment: .leading)
                                .padding(.vertical, getRelativeHeight(22.0))
                                .padding(.horizontal, getRelativeWidth(30.0))
                            }
                            .frame(width: getRelativeWidth(395.0), height: getRelativeHeight(423.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners()
                                .stroke(ColorConstants.WhiteA700, lineWidth: 3))
                            .background(RoundedCorners().fill(ColorConstants.Bluegray100))
                            .padding(.leading, getRelativeWidth(19.0))
                            .padding(.trailing, getRelativeWidth(38.0))
                            VStack {
                                Divider()
                                    .frame(width: UIScreen.main.bounds.width,
                                           height: getRelativeHeight(1.0), alignment: .center)
                                    .background(ColorConstants.WhiteA700)
                                Divider()
                                    .frame(width: UIScreen.main.bounds.width,
                                           height: getRelativeHeight(1.0), alignment: .center)
                                    .background(ColorConstants.WhiteA700)
                                    .padding(.top, getRelativeHeight(61.0))
                                Divider()
                                    .frame(width: UIScreen.main.bounds.width,
                                           height: getRelativeHeight(1.0), alignment: .center)
                                    .background(ColorConstants.WhiteA700)
                                    .padding(.top, getRelativeHeight(62.0))
                                Divider()
                                    .frame(width: UIScreen.main.bounds.width,
                                           height: getRelativeHeight(1.0), alignment: .center)
                                    .background(ColorConstants.WhiteA7007e)
                                    .padding(.top, getRelativeHeight(52.0))
                            }
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(179.0),
                                   alignment: .bottomLeading)
                            .padding(.top, getRelativeHeight(197.0))
                            Divider()
                                .frame(width: getRelativeWidth(399.0),
                                       height: getRelativeHeight(1.0), alignment: .topLeading)
                                .background(ColorConstants.WhiteA700)
                                .padding(.bottom, getRelativeHeight(366.37))
                                .padding(.trailing, getRelativeWidth(43.0))
                            Divider()
                                .frame(width: getRelativeWidth(399.0),
                                       height: getRelativeHeight(1.0), alignment: .topLeading)
                                .background(ColorConstants.WhiteA700)
                                .padding(.bottom, getRelativeHeight(304.98))
                                .padding(.trailing, getRelativeWidth(39.38))
                            Divider()
                                .frame(width: getRelativeWidth(3.0),
                                       height: getRelativeHeight(423.0), alignment: .leading)
                                .background(ColorConstants.WhiteA700)
                                .padding(.leading, getRelativeWidth(98.67))
                                .padding(.trailing, getRelativeWidth(350.33))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(435.0),
                               alignment: .leading)
                        .padding(.top, getRelativeHeight(5.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(765.0),
                           alignment: .center)
                    .background(ColorConstants.WhiteA700)
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(765.0),
                       alignment: .leading)
                .padding(.top, getRelativeHeight(23.0))
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.bottom, getRelativeHeight(26.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct InvestmentsView_Previews: PreviewProvider {
    static var previews: some View {
        InvestmentsView()
    }
}

import SwiftUI

struct CreditScoreView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        Image("img_line4")
                            .resizable()
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(1.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                        ZStack(alignment: .topLeading) {
                            Image("img_menu1")
                                .resizable()
                                .frame(width: getRelativeWidth(395.0),
                                       height: getRelativeHeight(171.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.leading, getRelativeWidth(20.0))
                            Image("img_icons8openmen")
                                .resizable()
                                .frame(width: getRelativeWidth(65.0),
                                       height: getRelativeHeight(76.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.bottom, getRelativeHeight(101.0))
                                .padding(.trailing, getRelativeWidth(350.0))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(415.0), height: getRelativeHeight(177.0),
                               alignment: .center)
                        .padding(.trailing, getRelativeWidth(15.0))
                        ZStack(alignment: .leading) {
                            Group {
                                Text(StringConstants.kLblVeryGood)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(30.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(140.0),
                                           height: getRelativeHeight(30.0), alignment: .topLeading)
                                    .padding(.bottom, getRelativeHeight(215.67))
                                    .padding(.trailing, getRelativeWidth(200.0))
                                Image("img_screenshot202")
                                    .resizable()
                                    .frame(width: getRelativeWidth(184.0),
                                           height: getRelativeHeight(326.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .background(RoundedCorners(topLeft: 43.0, topRight: 43.0,
                                                               bottomLeft: 43.0, bottomRight: 43.0))
                                    .padding(.trailing, getRelativeWidth(189.0))
                                ZStack {}
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(37.0),
                                           height: getRelativeHeight(74.0),
                                           alignment: .bottomTrailing)
                                    .background(ColorConstants.YellowA200)
                                    .padding(.top, getRelativeHeight(219.0))
                                    .padding(.leading, getRelativeWidth(176.0))
                                ZStack {}
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(38.0),
                                           height: getRelativeHeight(106.0),
                                           alignment: .bottomTrailing)
                                    .background(ColorConstants.LimeA700)
                                    .padding(.top, getRelativeHeight(187.0))
                                    .padding(.leading, getRelativeWidth(221.0))
                                ZStack {}
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(45.0),
                                           height: getRelativeHeight(153.0),
                                           alignment: .bottomTrailing)
                                    .background(ColorConstants.LightGreenA700)
                                    .padding(.top, getRelativeHeight(140.0))
                                    .padding(.leading, getRelativeWidth(267.0))
                                ZStack {}
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(44.0),
                                           height: getRelativeHeight(208.0),
                                           alignment: .bottomTrailing)
                                    .background(ColorConstants.GreenA700)
                                    .padding(.top, getRelativeHeight(85.0))
                                    .padding(.leading, getRelativeWidth(321.0))
                                ZStack {}
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(152.0),
                                           height: getRelativeHeight(28.0),
                                           alignment: .bottomLeading)
                                    .background(ColorConstants.WhiteA700)
                                    .padding(.top, getRelativeHeight(300.0))
                                    .padding(.trailing, getRelativeWidth(209.0))
                                Text(StringConstants.kLbl750)
                                    .font(FontScheme.kInterBold(size: getRelativeHeight(15.0)))
                                    .fontWeight(.bold)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(28.0),
                                           height: getRelativeHeight(15.0), alignment: .topLeading)
                                    .padding(.bottom, getRelativeHeight(256.38))
                                    .padding(.leading, getRelativeWidth(329.0))
                            }
                            Group {
                                Text(StringConstants.kLbl680)
                                    .font(FontScheme.kInterBold(size: getRelativeHeight(15.0)))
                                    .fontWeight(.bold)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(29.0),
                                           height: getRelativeHeight(15.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(164.62))
                                    .padding(.leading, getRelativeWidth(227.0))
                                Text(StringConstants.kLbl720)
                                    .font(FontScheme.kInterBold(size: getRelativeHeight(15.0)))
                                    .fontWeight(.bold)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(27.0),
                                           height: getRelativeHeight(15.0), alignment: .topLeading)
                                    .padding(.bottom, getRelativeHeight(197.38))
                                    .padding(.leading, getRelativeWidth(277.0))
                                Text(StringConstants.kLbl590)
                                    .font(FontScheme.kInterBold(size: getRelativeHeight(15.0)))
                                    .fontWeight(.bold)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(29.0),
                                           height: getRelativeHeight(15.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(195.62))
                                    .padding(.leading, getRelativeWidth(181.0))
                                Text(StringConstants.kMsgYourCreditSco)
                                    .font(FontScheme.kInterBold(size: getRelativeHeight(15.0)))
                                    .fontWeight(.bold)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(144.0),
                                           height: getRelativeHeight(36.0), alignment: .topLeading)
                                    .padding(.bottom, getRelativeHeight(273.0))
                                    .padding(.leading, getRelativeWidth(176.0))
                                Image("img_arrow1")
                                    .resizable()
                                    .frame(width: getRelativeWidth(133.0),
                                           height: getRelativeHeight(108.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.bottom, getRelativeHeight(146.0))
                                    .padding(.leading, getRelativeWidth(183.0))
                                ZStack {}
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(57.0),
                                           height: getRelativeHeight(30.0), alignment: .topTrailing)
                                    .overlay(RoundedCorners(topLeft: 28.5, topRight: 28.5,
                                                            bottomLeft: 28.5, bottomRight: 28.5)
                                            .stroke(ColorConstants.GreenA700,
                                                    lineWidth: 1))
                                    .background(RoundedCorners(topLeft: 28.5, topRight: 28.5,
                                                               bottomLeft: 28.5, bottomRight: 28.5)
                                            .fill(Color.clear.opacity(0.7)))
                                    .padding(.bottom, getRelativeHeight(247.0))
                                    .padding(.leading, getRelativeWidth(316.0))
                            }
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(373.0), height: getRelativeHeight(328.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(27.0))
                        .padding(.horizontal, getRelativeWidth(27.0))
                        Text(StringConstants.kMsgYourCreditSco3)
                            .font(FontScheme.kInterBold(size: getRelativeHeight(20.0)))
                            .fontWeight(.bold)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(208.0), height: getRelativeHeight(20.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(7.0))
                            .padding(.horizontal, getRelativeWidth(27.0))
                        ZStack(alignment: .trailing) {
                            VStack {
                                Text(StringConstants.kMsgHowToBoost)
                                    .font(FontScheme.kDomineRegular(size: getRelativeHeight(25.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(242.0),
                                           height: getRelativeHeight(25.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(17.0))
                                    .padding(.bottom, getRelativeHeight(14.0))
                                    .padding(.leading, getRelativeWidth(13.0))
                                    .padding(.trailing, getRelativeWidth(8.0))
                            }
                            .frame(width: getRelativeWidth(264.0), height: getRelativeHeight(57.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 15.0, topRight: 15.0, bottomLeft: 15.0,
                                                    bottomRight: 15.0)
                                    .stroke(ColorConstants.Black900,
                                            lineWidth: 2))
                            .background(RoundedCorners(topLeft: 15.0, topRight: 15.0,
                                                       bottomLeft: 15.0, bottomRight: 15.0)
                                    .fill(Color.clear.opacity(0.7)))
                            Divider()
                                .frame(width: getRelativeWidth(1.0),
                                       height: getRelativeHeight(58.0), alignment: .trailing)
                                .background(ColorConstants.Black900)
                                .padding(.leading, getRelativeWidth(214.0))
                                .padding(.trailing, getRelativeWidth(49.0))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(264.0), height: getRelativeHeight(58.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(27.0))
                        .padding(.horizontal, getRelativeWidth(27.0))
                        ZStack(alignment: .trailing) {
                            Text(StringConstants.kMsgCreditReport)
                                .font(FontScheme.kDomineRegular(size: getRelativeHeight(24.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(244.0),
                                       height: getRelativeHeight(24.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(17.07))
                                .padding(.leading, getRelativeWidth(12.52))
                                .padding(.trailing, getRelativeWidth(7.48))
                            Divider()
                                .frame(width: getRelativeWidth(1.0),
                                       height: getRelativeHeight(49.0), alignment: .trailing)
                                .background(ColorConstants.Black900)
                                .padding(.leading, getRelativeWidth(215.14))
                                .padding(.trailing, getRelativeWidth(47.86))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(264.0), height: getRelativeHeight(54.0),
                               alignment: .center)
                        .overlay(RoundedCorners(topLeft: 15.0, topRight: 15.0, bottomLeft: 15.0,
                                                bottomRight: 15.0)
                                .stroke(ColorConstants.Black900,
                                        lineWidth: 2))
                        .background(RoundedCorners(topLeft: 15.0, topRight: 15.0, bottomLeft: 15.0,
                                                   bottomRight: 15.0)
                                .fill(Color.clear.opacity(0.7)))
                        .padding(.top, getRelativeHeight(40.0))
                        .padding(.horizontal, getRelativeWidth(27.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                }
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.vertical, getRelativeHeight(79.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct CreditScoreView_Previews: PreviewProvider {
    static var previews: some View {
        CreditScoreView()
    }
}

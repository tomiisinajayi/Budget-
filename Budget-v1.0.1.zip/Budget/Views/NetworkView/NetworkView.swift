import SwiftUI

struct NetworkView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            ZStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        ZStack(alignment: .leading) {
                            Divider()
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(1.0), alignment: .bottomLeading)
                                .background(ColorConstants.Gray70056)
                                .padding(.top, getRelativeHeight(64.97))
                            Image("img_icons8openmen_76x71")
                                .resizable()
                                .frame(width: getRelativeWidth(71.0),
                                       height: getRelativeHeight(76.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.trailing, getRelativeWidth(359.0))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(76.0),
                               alignment: .leading)
                        Text(StringConstants.kLblBraggingRights)
                            .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(46.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.DeepPurpleA200)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(403.0), height: getRelativeHeight(46.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(46.0))
                            .padding(.horizontal, getRelativeWidth(12.0))
                        ZStack(alignment: .center) {
                            Text(StringConstants.kMsgAddYourScore)
                                .font(FontScheme.kInterRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.WhiteA700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(189.0),
                                       height: getRelativeHeight(53.0), alignment: .center)
                                .padding(.leading, getRelativeWidth(19.35))
                                .padding(.trailing, getRelativeWidth(6.65))
                            Text(StringConstants.kLblYourScore2)
                                .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(35.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.DeepPurpleA200)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(215.0),
                                       height: getRelativeHeight(35.0), alignment: .center)
                                .padding(.bottom, getRelativeHeight(10.67))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(215.0), height: getRelativeHeight(53.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(9.0))
                        .padding(.horizontal, getRelativeWidth(12.0))
                        ZStack(alignment: .center) {
                            Image("img_star3")
                                .resizable()
                                .frame(width: getRelativeWidth(225.0),
                                       height: getRelativeHeight(163.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Text(StringConstants.kLbl40)
                                .font(FontScheme.kSigmarOneRegular(size: getRelativeHeight(50.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.WhiteA700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(69.0),
                                       height: getRelativeHeight(50.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(60.82))
                                .padding(.horizontal, getRelativeWidth(78.2))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(225.0), height: getRelativeHeight(163.0),
                               alignment: .center)
                        .padding(.horizontal, getRelativeWidth(12.0))
                        Text(StringConstants.kMsgName)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(281.0), height: getRelativeHeight(25.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(36.0))
                            .padding(.horizontal, getRelativeWidth(12.0))
                        HStack {
                            Text(StringConstants.kLblDaveCaseyNaja)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(66.0),
                                       height: getRelativeHeight(110.0), alignment: .topLeading)
                            Spacer()
                            Text(StringConstants.kLbl324589)
                                .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(31.0),
                                       height: getRelativeHeight(105.0), alignment: .topLeading)
                                .padding(.bottom, getRelativeHeight(4.0))
                        }
                        .frame(width: getRelativeWidth(278.0), height: getRelativeHeight(110.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(38.0))
                        .padding(.horizontal, getRelativeWidth(12.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgShareYourScor)
                                    .font(FontScheme
                                        .kSrirachaRegular(size: getRelativeHeight(30.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(19.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(356.0),
                                           height: getRelativeHeight(68.0), alignment: .topLeading)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Bluegray100))
                                    .padding(.top, getRelativeHeight(87.0))
                                    .padding(.horizontal, getRelativeWidth(12.0))
                            }
                        })
                        .frame(width: getRelativeWidth(356.0), height: getRelativeHeight(68.0),
                               alignment: .topLeading)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Bluegray100))
                        .padding(.top, getRelativeHeight(87.0))
                        .padding(.horizontal, getRelativeWidth(12.0))
                        HStack {
                            Image("img_icons8instagra")
                                .resizable()
                                .frame(width: getRelativeWidth(50.0),
                                       height: getRelativeWidth(50.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Image("img_cd1f975b937b4")
                                .resizable()
                                .frame(width: getRelativeWidth(43.0),
                                       height: getRelativeHeight(39.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(5.0))
                                .padding(.bottom, getRelativeHeight(6.0))
                                .padding(.leading, getRelativeWidth(30.0))
                            Image("img_744a886475224")
                                .resizable()
                                .frame(width: getRelativeWidth(40.0),
                                       height: getRelativeHeight(39.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(5.0))
                                .padding(.bottom, getRelativeHeight(6.0))
                                .padding(.leading, getRelativeWidth(44.0))
                            Image("img_01d4a82c08da4")
                                .resizable()
                                .frame(width: getRelativeWidth(42.0),
                                       height: getRelativeHeight(39.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(5.0))
                                .padding(.bottom, getRelativeHeight(6.0))
                                .padding(.leading, getRelativeWidth(44.0))
                        }
                        .frame(width: getRelativeWidth(295.0), height: getRelativeHeight(50.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(19.0))
                        .padding(.horizontal, getRelativeWidth(12.0))
                        Text(StringConstants.kMsgInteractWithT)
                            .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(15.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(328.0), height: getRelativeHeight(19.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(56.0))
                            .padding(.horizontal, getRelativeWidth(12.0))
                    }
                    .frame(width: UIScreen.main.bounds.width)
                }
            }
            .hideNavigationBar()
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.vertical, getRelativeHeight(14.0))
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct NetworkView_Previews: PreviewProvider {
    static var previews: some View {
        NetworkView()
    }
}

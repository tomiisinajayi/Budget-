import SwiftUI

struct GoalsView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @State private var textfieldoneText: String = ""
    @State private var textfieldtwoText: String = ""
    @State private var textfieldthreeText: String = ""
    @State private var textfieldfourText: String = ""
    var body: some View {
        VStack {
            VStack {
                VStack(alignment: .leading, spacing: 0) {
                    Image("img_line4")
                        .resizable()
                        .frame(width: getRelativeWidth(76.0), height: getRelativeWidth(76.0),
                               alignment: .center)
                        .scaledToFit()
                        .clipped()
                        .padding(.trailing)
                    Divider()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(1.0),
                               alignment: .leading)
                        .background(ColorConstants.Gray70056)
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(76.0),
                       alignment: .leading)
                .padding(.top, getRelativeHeight(4.0))
                VStack {
                    Text(StringConstants.kLblLongTermGoals)
                        .font(FontScheme.kShrikhandRegular(size: getRelativeHeight(45.0)))
                        .fontWeight(.regular)
                        .foregroundColor(ColorConstants.DeepPurpleA200)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: getRelativeWidth(407.0), height: getRelativeHeight(44.0),
                               alignment: .topLeading)
                        .padding(.horizontal, getRelativeWidth(11.0))
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(44.0),
                       alignment: .leading)
                .padding(.top, getRelativeHeight(10.0))
                VStack(alignment: .leading, spacing: 0) {
                    Text(StringConstants.kLblSavingFor)
                        .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(15.0)))
                        .fontWeight(.regular)
                        .foregroundColor(ColorConstants.Purple700)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: getRelativeWidth(79.0), height: getRelativeHeight(16.0),
                               alignment: .topLeading)
                        .padding(.horizontal, getRelativeWidth(29.0))
                    Text(StringConstants.kMsg2023HondaCivi)
                        .font(FontScheme.kDomineBold(size: getRelativeHeight(15.0)))
                        .fontWeight(.bold)
                        .padding(.leading, getRelativeWidth(16.0))
                        .padding(.bottom, getRelativeHeight(17.0))
                        .padding(.top, getRelativeHeight(15.0))
                        .foregroundColor(ColorConstants.Black900)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: getRelativeWidth(360.0), height: getRelativeHeight(48.0),
                               alignment: .leading)
                        .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                bottomRight: 8.0)
                                .stroke(ColorConstants.Bluegray100,
                                        lineWidth: 2))
                        .background(ColorConstants.WhiteA700)
                        .padding(.top, getRelativeHeight(14.0))
                        .padding(.horizontal, getRelativeWidth(17.0))
                    Text(StringConstants.kLblBudget2)
                        .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(15.0)))
                        .fontWeight(.regular)
                        .foregroundColor(ColorConstants.Purple700)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: getRelativeWidth(58.0), height: getRelativeHeight(17.0),
                               alignment: .topLeading)
                        .padding(.top, getRelativeHeight(13.0))
                        .padding(.horizontal, getRelativeWidth(29.0))
                    Text(StringConstants.kLbl26000)
                        .font(FontScheme.kDomineBold(size: getRelativeHeight(15.0)))
                        .fontWeight(.bold)
                        .padding(.leading, getRelativeWidth(16.0))
                        .padding(.vertical, getRelativeHeight(16.0))
                        .foregroundColor(ColorConstants.Black900)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: getRelativeWidth(360.0), height: getRelativeHeight(48.0),
                               alignment: .leading)
                        .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                bottomRight: 8.0)
                                .stroke(ColorConstants.Bluegray100,
                                        lineWidth: 2))
                        .background(ColorConstants.WhiteA700)
                        .shadow(color: ColorConstants.Black9003f, radius: 4, x: 0, y: 4)
                        .padding(.top, getRelativeHeight(8.0))
                        .padding(.horizontal, getRelativeWidth(19.0))
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(165.0),
                       alignment: .leading)
                VStack(alignment: .trailing, spacing: 0) {
                    Text(StringConstants.kMsgYouVeSaved36)
                        .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(35.0)))
                        .fontWeight(.regular)
                        .foregroundColor(ColorConstants.Black900)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: getRelativeWidth(391.0), height: getRelativeHeight(88.0),
                               alignment: .topLeading)
                        .padding(.leading)
                        .padding(.leading)
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(88.0),
                       alignment: .leading)
                .padding(.top, getRelativeHeight(28.0))
                VStack(alignment: .leading, spacing: 0) {
                    Text(StringConstants.kLbl9360)
                        .font(FontScheme.kSrirachaRegular(size: getRelativeHeight(35.0)))
                        .fontWeight(.regular)
                        .foregroundColor(ColorConstants.Black900)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: getRelativeWidth(133.0), height: getRelativeHeight(35.0),
                               alignment: .topLeading)
                        .padding(.horizontal, getRelativeWidth(129.0))
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(35.0),
                       alignment: .leading)
                .padding(.top, getRelativeHeight(15.0))
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kLblCardNumber)
                            .font(FontScheme.kDomineRegular(size: getRelativeHeight(15.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Bluegray700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(96.0), height: getRelativeHeight(15.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(4.0))
                            .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            Spacer()
                            Image("img_vector")
                                .resizable()
                                .frame(width: getRelativeWidth(18.0),
                                       height: getRelativeHeight(13.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(18.0))
                                .padding(.bottom, getRelativeHeight(17.0))
                                .padding(.leading, getRelativeWidth(19.0))
                                .padding(.trailing, getRelativeWidth(11.0))
                            TextField(StringConstants.kMsg123456781234, text: $textfieldoneText)
                                .font(FontScheme.kDomineRegular(size: getRelativeHeight(15.0)))
                                .foregroundColor(ColorConstants.Black900)
                                .padding()
                        }
                        .frame(width: getRelativeWidth(289.0), height: getRelativeHeight(48.0),
                               alignment: .center)
                        .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                bottomRight: 8.0)
                                .stroke(ColorConstants.Bluegray100,
                                        lineWidth: 2))
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0)
                                .fill(ColorConstants.WhiteA700))
                        .padding(.top, getRelativeHeight(13.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            VStack(alignment: .leading, spacing: 0) {
                                Text(StringConstants.kLblExpires)
                                    .font(FontScheme.kDomineRegular(size: getRelativeHeight(15.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Bluegray700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(54.0),
                                           height: getRelativeHeight(15.0), alignment: .topLeading)
                                    .padding(.trailing)
                                HStack {
                                    Spacer()
                                    Image("img_vector_bluegray_700")
                                        .resizable()
                                        .frame(width: getRelativeWidth(16.0),
                                               height: getRelativeHeight(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(17.0))
                                        .padding(.leading, getRelativeWidth(20.0))
                                        .padding(.trailing, getRelativeWidth(12.0))
                                    TextField(StringConstants.kLbl0425, text: $textfieldtwoText)
                                        .font(FontScheme
                                            .kInterRegular(size: getRelativeHeight(15.0)))
                                        .foregroundColor(ColorConstants.Black900)
                                        .padding()
                                }
                                .frame(width: getRelativeWidth(132.0),
                                       height: getRelativeHeight(48.0), alignment: .leading)
                                .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                        bottomLeft: 8.0,
                                                        bottomRight: 8.0)
                                        .stroke(ColorConstants.Bluegray100,
                                                lineWidth: 2))
                                .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                           bottomLeft: 8.0, bottomRight: 8.0)
                                        .fill(ColorConstants.WhiteA700))
                                .padding(.top, getRelativeHeight(11.0))
                            }
                            .frame(width: getRelativeWidth(132.0), height: getRelativeHeight(74.0),
                                   alignment: .bottom)
                            .padding(.top, getRelativeHeight(4.0))
                            Spacer()
                            VStack(alignment: .leading, spacing: 0) {
                                Text(StringConstants.kLblSecurityCode)
                                    .font(FontScheme.kDomineRegular(size: getRelativeHeight(15.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Bluegray700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(97.0),
                                           height: getRelativeHeight(15.0), alignment: .topLeading)
                                    .padding(.trailing)
                                HStack {
                                    Spacer()
                                    Image("img_vector_bluegray_700_15x13")
                                        .resizable()
                                        .frame(width: getRelativeWidth(13.0),
                                               height: getRelativeHeight(15.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.top, getRelativeHeight(17.0))
                                        .padding(.bottom, getRelativeHeight(16.0))
                                        .padding(.leading, getRelativeWidth(22.0))
                                        .padding(.trailing, getRelativeWidth(13.0))
                                    TextField(StringConstants.kLbl222, text: $textfieldthreeText)
                                        .font(FontScheme
                                            .kInterRegular(size: getRelativeHeight(15.0)))
                                        .foregroundColor(ColorConstants.Black900)
                                        .padding()
                                }
                                .frame(width: getRelativeWidth(132.0),
                                       height: getRelativeHeight(48.0), alignment: .leading)
                                .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                        bottomLeft: 8.0,
                                                        bottomRight: 8.0)
                                        .stroke(ColorConstants.Bluegray100,
                                                lineWidth: 2))
                                .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                           bottomLeft: 8.0, bottomRight: 8.0)
                                        .fill(ColorConstants.WhiteA700))
                                .padding(.top, getRelativeHeight(11.0))
                            }
                            .frame(width: getRelativeWidth(132.0), height: getRelativeHeight(74.0),
                                   alignment: .bottom)
                            .padding(.top, getRelativeHeight(4.0))
                        }
                        .frame(width: getRelativeWidth(289.0), height: getRelativeHeight(79.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(24.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        Text(StringConstants.kLblCardholderName)
                            .font(FontScheme.kDomineRegular(size: getRelativeHeight(15.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Bluegray700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(125.0), height: getRelativeHeight(15.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(26.0))
                            .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            TextField(StringConstants.kLblEllenCooper, text: $textfieldfourText)
                                .font(FontScheme.kDomineRegular(size: getRelativeHeight(15.0)))
                                .foregroundColor(ColorConstants.Black900)
                                .padding()
                        }
                        .frame(width: getRelativeWidth(289.0), height: getRelativeHeight(48.0),
                               alignment: .center)
                        .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                bottomRight: 8.0)
                                .stroke(ColorConstants.Bluegray100,
                                        lineWidth: 2))
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0)
                                .fill(ColorConstants.WhiteA700))
                        .padding(.top, getRelativeHeight(13.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            Image("img_vector_bluegray_700_10x8")
                                .resizable()
                                .frame(width: getRelativeWidth(8.0),
                                       height: getRelativeHeight(10.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Text(StringConstants.kMsgYourTransactio)
                                .font(FontScheme.kDomineRegular(size: getRelativeHeight(12.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Bluegray700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(278.0),
                                       height: getRelativeHeight(14.0), alignment: .topLeading)
                        }
                        .frame(width: getRelativeWidth(290.0), height: getRelativeHeight(14.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(24.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        Button(action: {}, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblSave767Now)
                                    .font(FontScheme.kShortStack(size: getRelativeHeight(16.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(12.0))
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(289.0),
                                           height: getRelativeHeight(40.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 5.0, topRight: 5.0,
                                                               bottomLeft: 5.0, bottomRight: 5.0)
                                            .fill(ColorConstants.DeepPurpleA200))
                                    .padding(.top, getRelativeHeight(24.0))
                                    .padding(.horizontal, getRelativeWidth(24.0))
                            }
                        })
                        .frame(width: getRelativeWidth(289.0), height: getRelativeHeight(40.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 5.0, topRight: 5.0, bottomLeft: 5.0,
                                                   bottomRight: 5.0)
                                .fill(ColorConstants.DeepPurpleA200))
                        .padding(.top, getRelativeHeight(24.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            Image("img_vector_bluegray_700_10x8")
                                .resizable()
                                .frame(width: getRelativeWidth(8.0),
                                       height: getRelativeHeight(10.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Text(StringConstants.kMsgYourTransactio)
                                .font(FontScheme.kDomineRegular(size: getRelativeHeight(12.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Bluegray700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(277.0),
                                       height: getRelativeHeight(14.0), alignment: .topLeading)
                        }
                        .frame(width: getRelativeWidth(289.0), height: getRelativeHeight(14.0),
                               alignment: .center)
                        .padding(.vertical, getRelativeHeight(8.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                    }
                    .frame(width: getRelativeWidth(337.0), height: getRelativeHeight(435.0),
                           alignment: .center)
                    .overlay(RoundedCorners(topLeft: 5.0, topRight: 5.0, bottomLeft: 5.0,
                                            bottomRight: 5.0)
                            .stroke(ColorConstants.Bluegray50,
                                    lineWidth: 1))
                    .background(RoundedCorners(topLeft: 5.0, topRight: 5.0, bottomLeft: 5.0,
                                               bottomRight: 5.0)
                            .fill(ColorConstants.WhiteA700))
                    .shadow(color: ColorConstants.Bluegray90014, radius: 5, x: 0, y: 3)
                    .padding(.horizontal, getRelativeWidth(45.0))
                }
                .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(435.0),
                       alignment: .leading)
                .padding(.vertical, getRelativeHeight(8.0))
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.WhiteA700)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.WhiteA700)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct GoalsView_Previews: PreviewProvider {
    static var previews: some View {
        GoalsView()
    }
}
